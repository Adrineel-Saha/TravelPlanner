package com.cognizant.eureka.server.test.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.cognizant.eureka.server.main.EurekaServerApplication;

@SpringBootTest(classes=EurekaServerApplication.class)
public class EurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
