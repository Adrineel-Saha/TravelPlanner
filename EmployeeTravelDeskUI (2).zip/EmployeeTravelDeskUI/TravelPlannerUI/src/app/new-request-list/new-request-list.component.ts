import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { TravelRequest } from '../travel-request';
import { TravelRequestService } from '../travel-request.service';
import { AuthenticationService } from '../service/authentication.service';
import { Location } from '../location';
import { LocationService } from '../location.service';

@Component({
  selector: 'app-new-request-list',
  templateUrl: './new-request-list.component.html',
  styleUrls: ['./new-request-list.component.css']
})
export class NewRequestListComponent implements OnInit {
  travelRequests: TravelRequest[] = [];
  hrIdentifier!: number;
  showTable = false;
  isHRIdAbsent = false;
  isRequestRejected = false;
  isRequestApproved = false;
  isListEmpty = false;
  locations!: Location[];

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private travelRequestService: TravelRequestService,
    private locationService: LocationService,
    private authService: AuthenticationService
  ) {}

  ngOnInit() {
    // console.log('ngOnInit - Checking for updated request in state');
    // console.log('Initial value of showTable:', this.showTable);
    this.locationService.getAllLocations()
    .subscribe( data => {
      this.locations = data;
      console.log(data);
    },error=>console.log(error));

    const hrId = this.authService.getCurrentEmployeeId(); 
    
    if (hrId !== null) { 
      this.hrIdentifier = hrId; 
      // this.refreshTravelRequests(); 
    }

    if (history.state.updatedRequest) {
      const updatedRequest = history.state.updatedRequest;
      console.log('Updated request found:', updatedRequest);
      this.processUpdate(updatedRequest);
    }
    if (history.state.hrId) {
      this.hrIdentifier = history.state.hrId;
      this.refreshTravelRequests();
    }
    // console.log('Value of showTable after processing update in ngOnInit:', this.showTable);
  }

  newIntern(): void {
    this.showTable = false;
    this.isListEmpty = false;
    this.isRequestRejected = false;
    this.isRequestApproved = false;
  }

  submitHRId() {
    // console.log('Fetching pending travel requests for HR_ID:', this.hrIdentifier);
    this.travelRequestService.getAllPendingTravelRequests(this.hrIdentifier).subscribe(
      data => {
        this.travelRequests = data;
        this.showTable = this.travelRequests.length > 0;
        this.isListEmpty = this.travelRequests.length === 0;
        // console.log('Received travel requests:', this.travelRequests);
        // console.log('Updated value of showTable after fetching data:', this.showTable);
      },
      error => {
        if (error.status === 400) {
          this.isHRIdAbsent = true;
          setTimeout(() => {
            this.isHRIdAbsent = false;
          }, 3000);
        } else {
          console.log(error);
          // console.log('Error fetching travel requests:', error);
        }
      }
    );
  }

  refreshTravelRequests() {
    if (this.hrIdentifier) {
      // console.log('Refreshing pending travel requests for HR_ID:', this.hrIdentifier);
      this.travelRequestService.getAllPendingTravelRequests(this.hrIdentifier).subscribe(
        data => {
          this.travelRequests = data;
          this.showTable = this.travelRequests.length > 0;
          this.isListEmpty = this.travelRequests.length === 0;
          // console.log('Refreshed travel requests:', this.travelRequests);
          // console.log('Updated value of showTable after refreshing data:', this.showTable);
          // if (this.isListEmpty) { 
          //   setTimeout(() => { 
          //     this.isListEmpty = false; 
          //   }, 5000); 
          // }
        },
        error => {
          if(error.status===400){
            this.isListEmpty = this.travelRequests.length === 0;
            if (this.isListEmpty) { 
              setTimeout(() => { 
                this.isListEmpty = false; 
              }, 5000); 
            }
          }
          console.log(error);
          // console.log('Error refreshing travel requests:', error);
        }
      );
    }
  }

  processUpdate(updateTravelRequest: any) {
    // console.log('Processing update for request:', updateTravelRequest);
    if (this.travelRequests && this.travelRequests.length > 0) {
      this.travelRequests = this.travelRequests.filter(request => request.requestId !== updateTravelRequest.requestId);
    }

    if (updateTravelRequest.requestStatus === 'Rejected') {
      this.isRequestRejected = true;
      setTimeout(() => {
        this.isRequestRejected = false;
      }, 3000);
    } else if (updateTravelRequest.requestStatus === 'Approved') {
      this.isRequestApproved = true;
      setTimeout(() => {
        this.isRequestApproved = false;
      }, 3000);
    }

    this.showTable = this.travelRequests.length > 0;
    this.isListEmpty = this.travelRequests.length === 0;
    // console.log('Updated value of showTable after processing update:', this.showTable);
  }

  approveTravelRequest(requestId: number) {
    // console.log('Navigating to approval page for request ID:', requestId);
    this.router.navigate(['/approveOrRejectTravelRequestDetails', requestId], { state: { hrId: this.hrIdentifier} });
  }

  rejectTravelRequest(requestId: number) {
    // console.log('Navigating to rejection page for request ID:', requestId);
    this.router.navigate(['/approveOrRejectTravelRequestDetails',requestId], { state: { hrId: this.hrIdentifier} });
  }

  getLocation(locationId: number) {
    const location = this.locations.find(loc => loc.id === locationId); 
    return location ? location.name : undefined;
  }
}
