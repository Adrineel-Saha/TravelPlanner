export class Employee {
    
    employeeId!: number;
    employeeName!: string;
    password!: string;
    role!: string;
    currentGrade!: string;
    isAccountLocked!: boolean;

}
