import { UpdateTravelRequest } from './update-travel-request';

describe('UpdateTravelRequest', () => {
  it('should create an instance', () => {
    expect(new UpdateTravelRequest()).toBeTruthy();
  });
});
