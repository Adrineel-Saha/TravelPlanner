import { Component } from '@angular/core';
import { TravelRequest } from '../travel-request';
import { Router } from '@angular/router';
import { LocationService } from '../location.service';
import { TravelRequestService } from '../travel-request.service';
import { Location } from '../location';
import { AuthenticationService } from '../service/authentication.service';

@Component({
  selector: 'app-new-travel-request',
  templateUrl: './new-travel-request.component.html',
  styleUrls: ['./new-travel-request.component.css']
})
export class NewTravelRequestComponent {
  travelRequest: TravelRequest=new TravelRequest();
  formattedRequestRaisedOn = '';
  submitted = false;
  isMaximumDaysExceeded = false;
  travelRequestId!: number;
  locations!: Location[];
  priorities: string[] = ['Priority 1', 'Priority 2', 'Priority 3'];
  purposeOfTravelList: string[] = ['Business Meeting', 'Conference', 'Training', 'Project', 'Site Visit', 'Workshop', 'Seminar'];

  constructor(private router: Router, private locationService: LocationService, private travelRequestService: TravelRequestService, private authService: AuthenticationService) { }

  ngOnInit() {
    this.locationService.getAllLocations()
    .subscribe( data => {
      this.locations = data;
      console.log(data);
    },error=>console.log(error));

    const employeeId = this.authService.getCurrentEmployeeId(); 
    // console.log("New Travel Request Employee Id:",employeeId);

    if (employeeId !== null) { 
      this.travelRequest.raisedByEmployeeId = employeeId; 
    }

    this.travelRequest.toBeApprovedByHRId = this.getRandomHrId();
    this.travelRequest.requestStatus = 'New';
    this.travelRequest.requestRaisedOn=new Date();
    this.formattedRequestRaisedOn=this.travelRequest.requestRaisedOn.toISOString().split('T')[0];
    // console.log(this.travelRequest.toBeApprovedByHRId);
    // console.log(this.travelRequest.requestStatus);
    // console.log(this.travelRequest.requestRaisedOn);
  }

  newIntern(): void {
    this.submitted = false;
    this.travelRequest = new TravelRequest();
  }

  save() {
    this.travelRequestService.addTravelRequest(this.travelRequest)
      .subscribe(data =>{ 
        // console.log(data);
        // this.travelRequest=data;
        this.travelRequestId=data;
        this.submitted = true;
        this.travelRequest = new TravelRequest();
      }, error => {
        if(error.status===400 && error.error===('Exceeded maximum allowed on-site days for '+this.travelRequest.priority)){
          // console.log("error.error",error.error);
          this.isMaximumDaysExceeded=true;
          setTimeout(()=>{
            this.isMaximumDaysExceeded=false;
          },3000);
        } else{
          console.log(error);
        }
      });
    // this.loanApplication = new LoanApplication();
  }

  onSubmit() {
    // this.submitted = true;
    this.save();
  }

  // isCurrentDate(date: string): boolean { 
  //   if (!date) { 
  //     return false; // Return false if the date is not defined 
  //   } 
  //   const today = new Date().toISOString().split('T')[0]; 
  //   return today === date; 
  // }

  getRandomHrId(): number { 
    const min = 201; // Minimum HR ID value 
    const max = 207; // Maximum HR ID value 
    return Math.floor(Math.random() * (max - min + 1)) + min; // Generate a random HR ID within the range 
    }

  // Format date as YYYY-MM-DD string for display 
  // formatDate(date: Date): string { 
  //   return date.toISOString().split('T')[0]; 
  // }

  isFromDateValid(): boolean {
     if (!this.travelRequest.requestRaisedOn || !this.travelRequest.fromDate) { 
      return true; } 
      return new Date(this.travelRequest.fromDate) > new Date(this.travelRequest.requestRaisedOn); 
  }
  
}
