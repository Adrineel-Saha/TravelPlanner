export class UpdateTravelRequest {
    requestId!: number;
    requestStatus!: string;
    requestApprovedOn!: Date;
    approvedModeOfTravel!: string;
    approvedHotelStarRating!: string;
}
