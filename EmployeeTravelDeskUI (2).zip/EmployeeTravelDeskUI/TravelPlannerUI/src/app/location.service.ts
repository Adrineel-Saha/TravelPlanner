import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Location } from './location';

@Injectable({
  providedIn: 'root'
})
export class LocationService {

  constructor(private http:HttpClient) { }

  private getAllLocationsUrl="http://localhost:8080/api/travelrequests/locations";

  public getAllLocations(){
    return this.http.get<Location[]>(this.getAllLocationsUrl);
  }
}
