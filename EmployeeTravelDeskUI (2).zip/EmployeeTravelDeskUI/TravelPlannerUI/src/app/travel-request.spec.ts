import { TravelRequest } from './travel-request';

describe('TravelRequest', () => {
  it('should create an instance', () => {
    expect(new TravelRequest()).toBeTruthy();
  });
});
