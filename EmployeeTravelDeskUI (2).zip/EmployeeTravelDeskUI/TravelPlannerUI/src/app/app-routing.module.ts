import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NewTravelRequestComponent } from './new-travel-request/new-travel-request.component';
import { NewRequestListComponent } from './new-request-list/new-request-list.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { NavigationComponent } from './navigation/navigation.component';
import { RoleGuardService } from './service/role-guard.service';
import { TravelRequestDetailsComponent } from './travel-request-details/travel-request-details.component';

const routes: Routes = [
  { path: 'addTravelRequest', component: NewTravelRequestComponent, canActivate: [RoleGuardService], data: { roles: ['Employee', 'HR', 'TravelDeskExec'] } },
  { path: 'getAllPendingTravelRequests', component: NewRequestListComponent, canActivate: [RoleGuardService], data: { roles: ['HR'] } },
  { path: 'approveOrRejectTravelRequestDetails/:trid', component: TravelRequestDetailsComponent, canActivate: [RoleGuardService], data: { roles: ['HR'] } },
  { path: 'getApprovedTravelRequestDetails', component: TravelRequestDetailsComponent, canActivate: [RoleGuardService], data: { roles: ['Employee', 'TravelDeskExec'] } },
  { path: 'login', component: LoginComponent },
  { path: 'logout', component: LogoutComponent },
  { path: 'navigation', component: NavigationComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
