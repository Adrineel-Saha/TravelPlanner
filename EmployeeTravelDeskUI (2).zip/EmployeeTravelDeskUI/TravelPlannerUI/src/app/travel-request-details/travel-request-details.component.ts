import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ActivatedRouteSnapshot, Router, RouterStateSnapshot } from '@angular/router';
import { TravelRequestService } from '../travel-request.service';
import { TravelRequestDetails } from '../travel-request-details';
import { UpdateTravelRequest } from '../update-travel-request';
import { AuthenticationService } from '../service/authentication.service';

@Component({
  selector: 'app-travel-request-details',
  templateUrl: './travel-request-details.component.html',
  styleUrls: ['./travel-request-details.component.css']
})
export class TravelRequestDetailsComponent implements OnInit {
  travelRequestDetails: TravelRequestDetails = new TravelRequestDetails();
  travelRequestId!: number;
  hrIdentifier!: number;  // Add this line to declare hrIdentifier
  showDetailsEmployee = false;
  showDetailsHR = false;
  errorMessageUpdate = false;
  isTrIdAbsent = false;
  // initialRequestStatus = '';
  // travelRequestHRId!: number;
  isEmployeeRoleInvalid = false;
  modesOfTravel: string[] = ['Air', 'Train', 'Bus'];
  hotelRatings: string[] = ['3-Star', '5-Star', '7-Star'];
  isEmployee = true;

  constructor(private route: ActivatedRoute, private router: Router, private travelRequestService: TravelRequestService, private authService: AuthenticationService) {}

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('trid');
    const hrId = history.state.hrId;
    // console.log('id',id);
    // const requestRaisedOn = history.state.requestRaisedOn; 
    // const fromDate = history.state.fromDate;
    if (id) {
      this.isEmployee = false;
      this.travelRequestId = +id;
      // this.travelRequestDetails.requestRaisedOn = requestRaisedOn; 
      // this.travelRequestDetails.fromDate = fromDate;
      this.getApprovedTravelRequestDetails();
      // this.initialRequestStatus=this.travelRequestDetails.requestStatus;
      // console.log(this.initialRequestStatus);
      // this.showDetails=false;
      // if(this.travelRequestDetails.requestStatus==='Approved' || this.travelRequestDetails.requestStatus==='Rejected'){
      //   alert('Cannot update an Appp/Rejected Travel Request');
      // }
    }
    if (hrId) {
      this.hrIdentifier = hrId;
      // console.log(this.hrIdentifier);
    }
    else {
      const HrId = this.authService.getCurrentEmployeeId(); 
      if(HrId!=null){
        this.hrIdentifier = HrId;
        // console.log(this.hrIdentifier);
      }   
    }
  }

  newIntern(): void {
    this.showDetailsEmployee = false;
    this.showDetailsHR = false;
    // this.isTrIdAbsent = false;
    this.isEmployee = true;
    // this.initialRequestStatus = '';
    this.isEmployeeRoleInvalid = false;
    this.errorMessageUpdate = false;
  }

  getApprovedTravelRequestDetails() {
    this.travelRequestService.getApprovedTravelRequestDetails(this.travelRequestId).subscribe(
      data => {
        this.travelRequestDetails = data;

        if(this.isEmployee){
          this.showDetailsEmployee=true;
          setTimeout(() => {
            this.showDetailsEmployee = false;
          }, 10000);
        }

        // this.travelRequestHRId=this.travelRequestDetails.toBeApprovedByHRId;

        // this.initialRequestStatus=this.travelRequestDetails.requestStatus;
        
        // if(this.hrIdentifier!=this.travelRequestDetails.toBeApprovedByHRId){
        //   alert("This Travel Request is not allocated for HR_ID:"+this.hrIdentifier);
        // }

        // this.showDetails = true;
        // setTimeout(() => {
        //   this.showDetails = false;
        // }, 10000);
      },
      error => {
        if (error.status === 400 && (error.error==='Travel Request not found with id: '+this.travelRequestId || error.error.startsWith("Method parameter 'trid': Failed to convert value of type 'java.lang.String' to required type 'int'"))) {
          console.log(error.error);
          if(!this.isEmployee){
            alert('No Travel Reqest found with this id');
            this.showDetailsHR=true;
            // console.log(this.showDetailsHR);
          }
          this.isTrIdAbsent = true;
          setTimeout(() => {
            this.isTrIdAbsent = false;
          }, 3000);
        } else {
          console.log(error);
        }
      }
    );
  }

  toggleView() {
    const allowedRoles = ['HR']; 
    const employeeRole = this.authService.getCurrentEmployeeRole(); 
    
    if (allowedRoles.includes(employeeRole)) { 
      this.isEmployee = !this.isEmployee; 
      // this.showDetails = false; 
      this.travelRequestDetails = new TravelRequestDetails();
     } else { 
      console.log('Not authorized - Role mismatch'); 
      alert('Not authorized'); 
    }
  }

  submitApproval(): void {
    const updateTravelRequest = new UpdateTravelRequest();
    updateTravelRequest.requestId = this.travelRequestId;
    updateTravelRequest.requestApprovedOn = this.travelRequestDetails.requestApprovedOn;
    updateTravelRequest.requestStatus = this.travelRequestDetails.requestStatus;
    updateTravelRequest.approvedModeOfTravel = this.travelRequestDetails.approvedModeOfTravel;
    updateTravelRequest.approvedHotelStarRating = this.travelRequestDetails.approvedHotelStarRating;

    // if(this.initialRequestStatus==='Approved' || this.initialRequestStatus==='Rejected'){
    //   alert('Cannot update an Approved/Rejected Travel Request');
    // }

    if(this.hrIdentifier!=this.travelRequestDetails.toBeApprovedByHRId){
      alert("This Travel Request is not allocated for HR_ID:"+this.hrIdentifier);
    }
    // console.log("this.HrIdentifier",this.hrIdentifier);

    else{
      this.travelRequestService.updateTravelRequest(this.travelRequestId, updateTravelRequest).subscribe(
        () => {
          alert('Travel request approved/rejected successfully!');
          this.router.navigate(['/getAllPendingTravelRequests'], { state: { updatedRequest: updateTravelRequest , hrId: this.hrIdentifier} });
        },
        error => {
          if (error.status === 400 && error.error==='Invalid hotel star rating for employee role') {
            // console.log("error.error:",error.error);
            this.isEmployeeRoleInvalid = true;
            setTimeout(() => {
              this.isEmployeeRoleInvalid = false;
            }, 3000);
          } 
          else if (error.status === 400 && error.error==='Cannot update an Approved/Rejected Travel Request') {
              // console.log("error.error:",error.error);
              this.errorMessageUpdate = true;
              setTimeout(() => {
                this.errorMessageUpdate = false;
              }, 5000);
          }
          else {
            console.log(error);
          }
        }
      );
    }
    // this.travelRequestService.updateTravelRequest(this.travelRequestId, updateTravelRequest).subscribe(
    //   () => {
    //     alert('Travel request approved/rejected successfully!');
    //     this.router.navigate(['/getAllPendingTravelRequests'], { state: { updatedRequest: updateTravelRequest, hrId: this.hrIdentifier } });
    //   },
    //   error => {
    //     if (error.status === 400) {
    //       this.isEmployeeRoleInvalid = true;
    //       setTimeout(() => {
    //         this.isEmployeeRoleInvalid = false;
    //       }, 3000);
    //     } else {
    //       console.log(error);
    //     }
    //   }
    // );
  }
}
