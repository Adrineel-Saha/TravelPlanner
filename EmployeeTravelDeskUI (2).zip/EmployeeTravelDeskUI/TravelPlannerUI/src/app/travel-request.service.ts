import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TravelRequest } from './travel-request';
import { UpdateTravelRequest } from './update-travel-request';
import { TravelRequestDetails } from './travel-request-details';

@Injectable({
  providedIn: 'root'
})
export class TravelRequestService {

  constructor(private http:HttpClient) { }

  private addTravelRequestUrl="http://localhost:8080/api/travelrequests/new";
  private getAllPendingTravelRequestsUrl="http://localhost:8080/api/travelrequests";
  private updateTravelRequestUrl="http://localhost:8080/api/travelrequests";
  private getApprovedTravelRequestUrl="http://localhost:8080/api/travelrequests";

  public addTravelRequest(travelRequest:TravelRequest){
    return this.http.post<number>(this.addTravelRequestUrl,travelRequest);
  }

  public getAllPendingTravelRequests(HRId:number){
    return this.http.get<TravelRequest[]>(this.getAllPendingTravelRequestsUrl+"/"+HRId+"/pending");
  }

  public getApprovedTravelRequestDetails(trid:number){
    return this.http.get<TravelRequestDetails>(this.getApprovedTravelRequestUrl+"/"+trid);
  }

  public updateTravelRequest(trId:number,updateTravelRequest:UpdateTravelRequest){
    return this.http.put<TravelRequestDetails>(this.updateTravelRequestUrl+"/"+trId+"/update",updateTravelRequest);
  }
}
