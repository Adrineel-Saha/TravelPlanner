import { TravelRequestDetails } from './travel-request-details';

describe('TravelRequestDetails', () => {
  it('should create an instance', () => {
    expect(new TravelRequestDetails()).toBeTruthy();
  });
});
