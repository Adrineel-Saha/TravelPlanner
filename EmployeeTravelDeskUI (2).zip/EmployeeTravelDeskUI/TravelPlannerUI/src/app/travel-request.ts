export class TravelRequest {
    
    requestId!: number;
    raisedByEmployeeId!: number;
    employeeName!: string;
    toBeApprovedByHRId!: number;
    requestRaisedOn!: Date;
    fromDate!: Date;
    toDate!: Date;
    purposeOfTravel!: string;
    locationId!: number;
    requestStatus!: string;
    requestApprovedOn!: Date;
    priority!: string;
    
}
