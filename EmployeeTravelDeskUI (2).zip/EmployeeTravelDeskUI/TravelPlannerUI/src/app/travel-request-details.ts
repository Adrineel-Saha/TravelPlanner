export class TravelRequestDetails {

    requestId!: number;
    raisedByEmployeeId!: number;
    employeeName!: string;
    toBeApprovedByHRId!: number;
    requestRaisedOn!: Date;
    fromDate!: Date;
    toDate!: Date;
    purposeOfTravel!: string;
    locationId!: number;
    locationName!: string;
    requestStatus!: string;
    requestApprovedOn!: Date;
    priority!: string;
    approvedBudget!: number;
    approvedModeOfTravel!: string;
    approvedHotelStarRating!: string;
}
