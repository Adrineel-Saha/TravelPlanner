import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Employee } from '../employee';
import { catchError, map } from 'rxjs/operators';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private http: HttpClient) { }

  authenticateURL: string = "http://localhost:8080/authenticate/employees";

  authenticate(employeeName: string, password: string): Observable<boolean> {
    const employee: Employee = {
      employeeName: employeeName,
      password: password,
      role: '',
      isAccountLocked: false,
      employeeId: 0,
      currentGrade: ''
    };

    return this.http.post<Employee>(this.authenticateURL, employee).pipe(
      map(data => {
        if (data.employeeName === employeeName && data.password === password) {
          sessionStorage.setItem('employeeName', employeeName);
          sessionStorage.setItem('employeeId', data.employeeId.toString());
          sessionStorage.setItem('role', data.role);
          // console.log("CORRECT username and password matches");
          return true;
        } else {
          // console.log("INCORRECT username and password matches");
          return false;
        }
      }),
      catchError(() => {
        return of(false);
      })
    );
  }

  isEmployeeLoggedIn(): boolean {
    let employee = sessionStorage.getItem('employeeName');
    let role = sessionStorage.getItem('role');
    // console.log('isEmployeeLoggedIn:', !(employee === null));
    return !(employee === null && role === null);
  }

  getCurrentEmployeeRole(): string {
    let role = sessionStorage.getItem('role');
    return role ? role : '';
  }

  getCurrentEmployeeId() { 
    let employeeId = sessionStorage.getItem('employeeId'); 
    // console.log("Authentication Employee Id:",employeeId);
    return employeeId ? parseInt(employeeId) : null; 
  }

  logOut() {
    sessionStorage.removeItem('employeeName');
    sessionStorage.removeItem('employeeId');
    sessionStorage.removeItem('role');
  }
}
