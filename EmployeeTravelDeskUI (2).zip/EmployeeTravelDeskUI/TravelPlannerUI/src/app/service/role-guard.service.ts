import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthenticationService } from './authentication.service';

@Injectable({
  providedIn: 'root'
})
export class RoleGuardService implements CanActivate {

  constructor(private authService: AuthenticationService, private router: Router) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    // console.log('RoleGuardService - Checking authorization for specific roles');

    if (!this.authService.isEmployeeLoggedIn()) {
      // console.log('Not authorized - Not logged in');
      this.router.navigate(['login']);
      return false;
    }

    const allowedRoles = route.data['roles'] as Array<string>;
    const employeeRole = this.authService.getCurrentEmployeeRole();

    if (allowedRoles.includes(employeeRole)) {
      // console.log(`Authorized as ${employeeRole}`);
      return true;
    } else {
      // console.log('Not authorized - Role mismatch');
      alert('Not authorized');
      // this.router.navigate(['']);
      return false;
    }
  }
}
