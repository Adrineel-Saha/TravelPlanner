import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  employeeName: string= '';
  password :string= '';

  constructor(private router: Router,private loginservice: AuthenticationService) { }

  ngOnInit() {
  }

  checkLogin(){
    // console.log(this.employeeName);
    // console.log(this.password);

    this.loginservice.authenticate(this.employeeName, this.password).subscribe(authenticated => {
      if (authenticated) {
        this.router.navigate(['navigation']);
      } else {
        alert("Either your username or password is incorrect!!!");
      }
      this.employeeName = '';
      this.password = '';
    });
  }

  isLoggedIn():boolean{
    return this.loginservice.isEmployeeLoggedIn();
  }
}
