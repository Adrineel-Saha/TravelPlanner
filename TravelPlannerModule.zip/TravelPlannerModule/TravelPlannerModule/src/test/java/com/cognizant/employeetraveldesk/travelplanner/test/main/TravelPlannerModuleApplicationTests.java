package com.cognizant.employeetraveldesk.travelplanner.test.main;

import com.cognizant.employeetraveldesk.travelplanner.controllers.TravelPlannerController;
import com.cognizant.employeetraveldesk.travelplanner.main.TravelPlannerModuleApplication;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest(classes= TravelPlannerModuleApplication.class)
class TravelPlannerModuleApplicationTests {
	@Autowired
	private TravelPlannerController travelPlannerController;

	@Test
	void contextLoads() {
		assertNotNull(travelPlannerController);
	}

}
