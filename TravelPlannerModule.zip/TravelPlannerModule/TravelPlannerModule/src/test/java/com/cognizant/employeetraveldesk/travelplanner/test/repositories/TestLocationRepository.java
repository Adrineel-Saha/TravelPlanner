package com.cognizant.employeetraveldesk.travelplanner.test.repositories;

import com.cognizant.employeetraveldesk.travelplanner.entities.Location;
import com.cognizant.employeetraveldesk.travelplanner.main.TravelPlannerModuleApplication;
import com.cognizant.employeetraveldesk.travelplanner.repositories.LocationRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertTrue;

@DataJpaTest
@ContextConfiguration(classes = TravelPlannerModuleApplication.class)
public class TestLocationRepository {
    @Autowired
    private LocationRepository locationRepository;
    @Autowired
    private TestEntityManager entityManager;

    @Test
    public void testFindAllPositive() {
        Location location = new Location();
        location.setId(1);
        location.setName("Delhi");

        entityManager.persist(location);
        Iterable<Location> locationIterable = locationRepository.findAll();
        assertTrue(locationIterable.iterator().hasNext());
    }

    @Test
    public void testFindAllNegative() {
        Iterable<Location> locationIterable = locationRepository.findAll();
        assertTrue(!locationIterable.iterator().hasNext());
    }


    @Test
    public void testFindByIdPositive() {
        Location location = new Location();
        location.setId(2);
        location.setName("Mumbai");

        entityManager.persist(location);
        Optional<Location> locationOptional = locationRepository.findById(2);
        assertTrue(locationOptional.isPresent());
    }

    @Test
    public void testFindByIdNegative() {
        Optional<Location> locationOptional = locationRepository.findById(2);
        assertTrue(!locationOptional.isPresent());
    }

    @Test
    public void testSavePositive() {
        Location location = new Location();
        location.setId(3);
        location.setName("Hyderabad");

        locationRepository.save(location);
        Optional<Location> locationOptional = locationRepository.findById(3);
        assertTrue(locationOptional.isPresent());
    }

    @Test
    public void testSaveNegative() {
        Optional<Location> locationOptional = locationRepository.findById(3);
        assertTrue(!locationOptional.isPresent());
    }

    @Test
    public void testDeletePositive() {
        Location location = new Location();
        location.setId(4);
        location.setName("Kolkata");

        locationRepository.delete(location);
        Optional<Location> locationOptional = locationRepository.findById(3);
        assertTrue(!locationOptional.isPresent());
    }

    @Test
    public void testDeleteNegative() {
        Optional<Location> locationOptional = locationRepository.findById(3);
        assertTrue(!locationOptional.isPresent());
    }
}
