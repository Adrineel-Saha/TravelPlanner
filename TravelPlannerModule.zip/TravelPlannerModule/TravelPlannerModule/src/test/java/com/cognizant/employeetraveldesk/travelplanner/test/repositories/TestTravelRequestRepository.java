package com.cognizant.employeetraveldesk.travelplanner.test.repositories;

import com.cognizant.employeetraveldesk.travelplanner.entities.Location;
import com.cognizant.employeetraveldesk.travelplanner.entities.TravelRequest;
import com.cognizant.employeetraveldesk.travelplanner.main.TravelPlannerModuleApplication;
import com.cognizant.employeetraveldesk.travelplanner.repositories.TravelRequestRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import java.util.Date;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertTrue;

@DataJpaTest
@ContextConfiguration(classes = TravelPlannerModuleApplication.class)
public class TestTravelRequestRepository {
    @Autowired
    private TravelRequestRepository travelRequestRepository;
    @Autowired
    private TestEntityManager entityManager;

    @Test
    public void testFindAllPositive() {
        TravelRequest travelRequest=new TravelRequest();

        travelRequest.setRequestId(1);
        travelRequest.setRaisedByEmployeeId(101);
        travelRequest.setToBeApprovedByHRId(201);
        travelRequest.setRequestRaisedOn(new Date());
        travelRequest.setFromDate(new Date(2025,1,15));
        travelRequest.setToDate(new Date(2025,1,20));
        travelRequest.setPurposeOfTravel("Business Meeting");
        travelRequest.setRequestStatus("Approved");
        travelRequest.setRequestApprovedOn(new Date(2025,1,10));
        travelRequest.setPriority("Priority 1");

        Location location = new Location();
        location.setId(1);
        location.setName("Delhi");

        entityManager.persist(location);

        travelRequest.setLocation(location);

        entityManager.persist(travelRequest);
        Iterable<TravelRequest> travelRequestIterable = travelRequestRepository.findAll();
        assertTrue(travelRequestIterable.iterator().hasNext());
    }

    @Test
    public void testFindAllNegative() {
        Iterable<TravelRequest> travelRequestIterable = travelRequestRepository.findAll();
        assertTrue(!travelRequestIterable.iterator().hasNext());
    }


    @Test
    public void testFindByIdPositive() {
        TravelRequest travelRequest=new TravelRequest();

        travelRequest.setRequestId(2);
        travelRequest.setRaisedByEmployeeId(102);
        travelRequest.setToBeApprovedByHRId(202);
        travelRequest.setRequestRaisedOn(new Date());
        travelRequest.setFromDate(new Date(2025,1,20));
        travelRequest.setToDate(new Date(2025,1,25));
        travelRequest.setPurposeOfTravel("Conference");
        travelRequest.setRequestStatus("Approved");
        travelRequest.setRequestApprovedOn(new Date(2025,1,15));
        travelRequest.setPriority("Priority 2");

        Location location = new Location();
        location.setId(2);
        location.setName("Mumbai");

        travelRequest.setLocation(location);

        entityManager.persist(travelRequest);
        Optional<TravelRequest> travelRequestOptional = travelRequestRepository.findById(2);
        assertTrue(travelRequestOptional.isPresent());
    }

    @Test
    public void testFindByIdNegative() {
        Optional<TravelRequest> travelRequestOptional = travelRequestRepository.findById(2);
        assertTrue(!travelRequestOptional.isPresent());
    }

    @Test
    public void testSavePositive() {
        TravelRequest travelRequest=new TravelRequest();

        travelRequest.setRequestId(3);
        travelRequest.setRaisedByEmployeeId(103);
        travelRequest.setToBeApprovedByHRId(203);
        travelRequest.setRequestRaisedOn(new Date());
        travelRequest.setFromDate(new Date(2025,1,25));
        travelRequest.setToDate(new Date(2025,11,30));
        travelRequest.setPurposeOfTravel("Training");
        travelRequest.setRequestStatus("Rejected");
        travelRequest.setRequestApprovedOn(null);
        travelRequest.setPriority("Priority 3");

        Location location = new Location();
        location.setId(3);
        location.setName("Hyderabad");

        entityManager.persist(location);

        travelRequest.setLocation(location);

        travelRequestRepository.save(travelRequest);
        Optional<TravelRequest> travelRequestOptional = travelRequestRepository.findById(3);
        assertTrue(travelRequestOptional.isPresent());
    }

    @Test
    public void testSaveNegative() {
        Optional<TravelRequest> travelRequestOptional = travelRequestRepository.findById(3);
        assertTrue(!travelRequestOptional.isPresent());
    }

    @Test
    public void testDeletePositive() {
        TravelRequest travelRequest=new TravelRequest();

        travelRequest.setRequestId(4);
        travelRequest.setRaisedByEmployeeId(104);
        travelRequest.setToBeApprovedByHRId(204);
        travelRequest.setRequestRaisedOn(new Date());
        travelRequest.setFromDate(new Date(2025,2,1));
        travelRequest.setToDate(new Date(2025,2,5));
        travelRequest.setPurposeOfTravel("Project");
        travelRequest.setRequestStatus("Approved");
        travelRequest.setRequestApprovedOn(new Date(2025,1,25));
        travelRequest.setPriority("Priority 3");

        Location location = new Location();
        location.setId(4);
        location.setName("Kolkata");

        travelRequest.setLocation(location);

        entityManager.persist(travelRequest);

        travelRequestRepository.delete(travelRequest);
        Optional<TravelRequest> travelRequestOptional = travelRequestRepository.findById(4);
        assertTrue(!travelRequestOptional.isPresent());
    }

    @Test
    public void testDeleteNegative() {
        Optional<TravelRequest> travelRequestOptional = travelRequestRepository.findById(4);
        assertTrue(!travelRequestOptional.isPresent());
    }
}
