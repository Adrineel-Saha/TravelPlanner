package com.cognizant.employeetraveldesk.travelplanner.test.repositories;

import com.cognizant.employeetraveldesk.travelplanner.entities.TravelBudgetAllocation;
import com.cognizant.employeetraveldesk.travelplanner.entities.TravelRequest;
import com.cognizant.employeetraveldesk.travelplanner.main.TravelPlannerModuleApplication;
import com.cognizant.employeetraveldesk.travelplanner.repositories.TravelBudgetAllocationRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import java.util.Date;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertTrue;

@DataJpaTest
@ContextConfiguration(classes = TravelPlannerModuleApplication.class)
public class TestTravelBudgetAllocationRepository {

    @Autowired
    private TravelBudgetAllocationRepository travelBudgetAllocationRepository;
    @Autowired
    private TestEntityManager entityManager;

    @Test
    public void testFindAllPositive() {
        TravelBudgetAllocation travelBudgetAllocation = new TravelBudgetAllocation();
        travelBudgetAllocation.setApprovedBudget(60000);
        travelBudgetAllocation.setApprovedModeOfTravel("Air");
        travelBudgetAllocation.setApprovedHotelStarRating("5-Star");

        TravelRequest travelRequest = new TravelRequest();
        travelRequest.setRaisedByEmployeeId(101);
        travelRequest.setToBeApprovedByHRId(201);
        travelRequest.setRequestRaisedOn(new Date());
        travelRequest.setFromDate(new Date(2025, 1, 15));
        travelRequest.setToDate(new Date(2025, 1, 20));
        travelRequest.setPurposeOfTravel("Business Meeting");
        travelRequest.setRequestStatus("Approved");
        travelRequest.setRequestApprovedOn(new Date(2025, 1, 10));
        travelRequest.setPriority("Priority 1");

        entityManager.persist(travelRequest);
        travelBudgetAllocation.setTravelRequest(travelRequest);

        entityManager.persist(travelBudgetAllocation);
        entityManager.flush();
        entityManager.clear();

        Iterable<TravelBudgetAllocation> travelBudgetAllocationIterable = travelBudgetAllocationRepository.findAll();
        assertTrue(travelBudgetAllocationIterable.iterator().hasNext());
    }

    @Test
    public void testFindAllNegative() {
        Iterable<TravelBudgetAllocation> travelBudgetAllocationIterable = travelBudgetAllocationRepository.findAll();
        assertTrue(!travelBudgetAllocationIterable.iterator().hasNext());
    }

    @Test
    public void testFindByIdPositive() {
        TravelBudgetAllocation travelBudgetAllocation = new TravelBudgetAllocation();
        travelBudgetAllocation.setApprovedBudget(75000);
        travelBudgetAllocation.setApprovedModeOfTravel("Train");
        travelBudgetAllocation.setApprovedHotelStarRating("3-Star");

        TravelRequest travelRequest = new TravelRequest();
        travelRequest.setRaisedByEmployeeId(102);
        travelRequest.setToBeApprovedByHRId(202);
        travelRequest.setRequestRaisedOn(new Date());
        travelRequest.setFromDate(new Date(2025, 1, 20));
        travelRequest.setToDate(new Date(2025, 1, 25));
        travelRequest.setPurposeOfTravel("Conference");
        travelRequest.setRequestStatus("Approved");
        travelRequest.setRequestApprovedOn(new Date(2025, 1, 15));
        travelRequest.setPriority("Priority 2");

        entityManager.persist(travelRequest);
        travelBudgetAllocation.setTravelRequest(travelRequest);

        TravelBudgetAllocation savedBudgetAllocation = entityManager.persistAndFlush(travelBudgetAllocation);
        entityManager.clear();

        Optional<TravelBudgetAllocation> travelBudgetAllocationOptional = travelBudgetAllocationRepository.findById(savedBudgetAllocation.getId());
        assertTrue(travelBudgetAllocationOptional.isPresent());
    }

    @Test
    public void testFindByIdNegative() {
        Optional<TravelBudgetAllocation> travelBudgetAllocationOptional = travelBudgetAllocationRepository.findById(2);
        assertTrue(!travelBudgetAllocationOptional.isPresent());
    }

    @Test
    public void testSavePositive() {
        TravelBudgetAllocation travelBudgetAllocation = new TravelBudgetAllocation();
        travelBudgetAllocation.setApprovedBudget(0);
        travelBudgetAllocation.setApprovedModeOfTravel(null);
        travelBudgetAllocation.setApprovedHotelStarRating(null);

        TravelRequest travelRequest = new TravelRequest();
        travelRequest.setRaisedByEmployeeId(103);
        travelRequest.setToBeApprovedByHRId(203);
        travelRequest.setRequestRaisedOn(new Date());
        travelRequest.setFromDate(new Date(2025, 1, 25));
        travelRequest.setToDate(new Date(2025, 11, 30));
        travelRequest.setPurposeOfTravel("Training");
        travelRequest.setRequestStatus("Rejected");
        travelRequest.setRequestApprovedOn(null);
        travelRequest.setPriority("Priority 3");

        entityManager.persist(travelRequest);
        travelBudgetAllocation.setTravelRequest(travelRequest);

        TravelBudgetAllocation savedBudgetAllocation = travelBudgetAllocationRepository.save(travelBudgetAllocation);
        entityManager.flush();
        entityManager.clear();

        Optional<TravelBudgetAllocation> travelBudgetAllocationOptional = travelBudgetAllocationRepository.findById(savedBudgetAllocation.getId());
        assertTrue(travelBudgetAllocationOptional.isPresent());
    }

    @Test
    public void testSaveNegative() {
        Optional<TravelBudgetAllocation> travelBudgetAllocationOptional = travelBudgetAllocationRepository.findById(3);
        assertTrue(!travelBudgetAllocationOptional.isPresent());
    }

    @Test
    public void testDeletePositive() {
        TravelBudgetAllocation travelBudgetAllocation = new TravelBudgetAllocation();
        travelBudgetAllocation.setApprovedBudget(75000);
        travelBudgetAllocation.setApprovedModeOfTravel("Air");
        travelBudgetAllocation.setApprovedHotelStarRating("5-Star");

        TravelRequest travelRequest = new TravelRequest();
        travelRequest.setRaisedByEmployeeId(104);
        travelRequest.setToBeApprovedByHRId(204);
        travelRequest.setRequestRaisedOn(new Date());
        travelRequest.setFromDate(new Date(2025, 2, 1));
        travelRequest.setToDate(new Date(2025, 2, 5));
        travelRequest.setPurposeOfTravel("Project");
        travelRequest.setRequestStatus("Approved");
        travelRequest.setRequestApprovedOn(new Date(2025, 1, 25));
        travelRequest.setPriority("Priority 3");

        entityManager.persist(travelRequest);
        travelBudgetAllocation.setTravelRequest(travelRequest);

        TravelBudgetAllocation savedBudgetAllocation = entityManager.persistAndFlush(travelBudgetAllocation);
        entityManager.clear();

        travelBudgetAllocationRepository.delete(savedBudgetAllocation);
        Optional<TravelBudgetAllocation> travelBudgetAllocationOptional = travelBudgetAllocationRepository.findById(savedBudgetAllocation.getId());
        assertTrue(!travelBudgetAllocationOptional.isPresent());
    }

    @Test
    public void testDeleteNegative() {
        Optional<TravelBudgetAllocation> travelBudgetAllocationOptional = travelBudgetAllocationRepository.findById(4);
        assertTrue(!travelBudgetAllocationOptional.isPresent());
    }
}
