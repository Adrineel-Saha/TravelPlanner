package com.cognizant.employeetraveldesk.travelplanner.test.services;

import com.cognizant.employeetraveldesk.travelplanner.dtos.TravelRequestDTO;
import com.cognizant.employeetraveldesk.travelplanner.dtos.TravelRequestDetailsDTO;
import com.cognizant.employeetraveldesk.travelplanner.dtos.UpdateTravelRequestDTO;
import com.cognizant.employeetraveldesk.travelplanner.entities.Location;
import com.cognizant.employeetraveldesk.travelplanner.entities.TravelBudgetAllocation;
import com.cognizant.employeetraveldesk.travelplanner.entities.TravelRequest;
import com.cognizant.employeetraveldesk.travelplanner.repositories.LocationRepository;
import com.cognizant.employeetraveldesk.travelplanner.repositories.TravelBudgetAllocationRepository;
import com.cognizant.employeetraveldesk.travelplanner.repositories.TravelRequestRepository;
import com.cognizant.employeetraveldesk.travelplanner.services.EmployeeService;
import com.cognizant.employeetraveldesk.travelplanner.services.TravelRequestServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class TestTravelRequestServiceImpl {

    @Mock
    TravelRequestRepository travelRequestRepository;

    @Mock
    LocationRepository locationRepository;

    @Mock
    TravelBudgetAllocationRepository travelBudgetAllocationRepository;

    @Mock
    EmployeeService employeeService;

    @Mock
    ModelMapper modelMapper;

    @InjectMocks
    private TravelRequestServiceImpl travelRequestServiceImpl;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @AfterEach
    void tearDown() throws Exception {

    }

    @Test
    public void testAddTravelRequestPositive(){
        try{
            TravelRequestDTO travelRequestDTO =new TravelRequestDTO();

            travelRequestDTO.setRequestId(1);
            travelRequestDTO.setRaisedByEmployeeId(101);
            travelRequestDTO.setToBeApprovedByHRId(201);
            travelRequestDTO.setRequestRaisedOn(new Date());
            travelRequestDTO.setFromDate(new Date(2025,1,15));
            travelRequestDTO.setToDate(new Date(2025,1,20));
            travelRequestDTO.setPurposeOfTravel("Business Meeting");
            travelRequestDTO.setRequestStatus("Approved");
            travelRequestDTO.setRequestApprovedOn(new Date(2025,1,10));
            travelRequestDTO.setPriority("Priority 1");
            travelRequestDTO.setLocationId(1);
            travelRequestDTO.setEmployeeName("Adrineel");

            Location location = new Location();
            location.setId(1);
            location.setName("Delhi");

            when(locationRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(location));

            TravelRequest travelRequest=new TravelRequest();

            travelRequest.setRequestId(1);
            travelRequest.setRaisedByEmployeeId(101);
            travelRequest.setToBeApprovedByHRId(201);
            travelRequest.setRequestRaisedOn(new Date());
            travelRequest.setFromDate(new Date(2025,1,15));
            travelRequest.setToDate(new Date(2025,1,20));
            travelRequest.setPurposeOfTravel("Business Meeting");
            travelRequest.setRequestStatus("Approved");
            travelRequest.setRequestApprovedOn(new Date(2025,1,10));
            travelRequest.setPriority("Priority 1");
            travelRequest.setLocation(location);

            when(modelMapper.map(Mockito.any(TravelRequestDTO.class),Mockito.eq(TravelRequest.class))).thenReturn(travelRequest);
            when(travelRequestRepository.save(Mockito.any())).thenReturn(travelRequest);

            TravelBudgetAllocation travelBudgetAllocation=new TravelBudgetAllocation();
            travelBudgetAllocation.setApprovedBudget(50000);
            travelBudgetAllocation.setApprovedModeOfTravel("Bus");
            travelBudgetAllocation.setApprovedModeOfTravel("3-Star");
            travelBudgetAllocation.setTravelRequest(travelRequest);

            when(travelBudgetAllocationRepository.save(Mockito.any())).thenReturn(travelBudgetAllocation);

            TravelRequestDetailsDTO travelRequestDetailsDTO=new TravelRequestDetailsDTO();
            travelRequestDetailsDTO.setRequestId(1);
            travelRequestDetailsDTO.setRaisedByEmployeeId(101);
            travelRequestDetailsDTO.setToBeApprovedByHRId(201);
            travelRequestDetailsDTO.setRequestRaisedOn(new Date());
            travelRequestDetailsDTO.setFromDate(new Date(2025,1,15));
            travelRequestDetailsDTO.setToDate(new Date(2025,1,20));
            travelRequestDetailsDTO.setPurposeOfTravel("Business Meeting");
            travelRequestDetailsDTO.setLocationId(1);
            travelRequestDetailsDTO.setLocationName("Delhi");
            travelRequestDetailsDTO.setRequestStatus("Approved");
            travelRequestDetailsDTO.setRequestApprovedOn(new Date(2025,1,10));
            travelRequestDetailsDTO.setPriority("Priority 1");
            travelRequestDetailsDTO.setApprovedBudget(60000);
            travelRequestDetailsDTO.setApprovedModeOfTravel("Air");
            travelRequestDetailsDTO.setApprovedModeOfTravel("5-Star");
            travelRequestDetailsDTO.setEmployeeName("Adrineel");


//            when(modelMapper.map(Mockito.any(TravelRequest.class),Mockito.eq(TravelRequestDTO.class))).thenReturn(travelRequestDTO);

            when(modelMapper.map(Mockito.any(TravelRequest.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);
            when(modelMapper.map(Mockito.any(Location.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);
            when(modelMapper.map(Mockito.any(TravelBudgetAllocation.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);

            TravelRequestDetailsDTO actualTravelRequestDetailsDTO =travelRequestServiceImpl.addTravelRequest(travelRequestDTO);
            assertNotNull(actualTravelRequestDetailsDTO);
        }catch(Exception e){
            //e.printStackTrace();
            //	System.out.println(e);
            assertTrue(false);
        }
    }

    @Test
    public void testAddTravelRequestNegativeWhenTravelRequestIsInvalid(){
        try{
            TravelRequestDTO travelRequestDTO =new TravelRequestDTO();

            travelRequestDTO.setRequestId(1);
            travelRequestDTO.setRaisedByEmployeeId(101);
            travelRequestDTO.setToBeApprovedByHRId(201);
            travelRequestDTO.setRequestRaisedOn(new Date());
            travelRequestDTO.setFromDate(new Date(2025,1,15));
            travelRequestDTO.setToDate(new Date(2025,1,20));
            travelRequestDTO.setPurposeOfTravel("Business Meeting");
            travelRequestDTO.setRequestStatus("Approved");
            travelRequestDTO.setRequestApprovedOn(new Date(2025,1,10));
            travelRequestDTO.setPriority("Priority 1");
            travelRequestDTO.setLocationId(1);
            travelRequestDTO.setEmployeeName("Adrineel");

            Location location = new Location();
            location.setId(1);
            location.setName("Delhi");

            when(locationRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(location));

            TravelRequest travelRequest=new TravelRequest();

            travelRequest.setRequestId(1);
            travelRequest.setRaisedByEmployeeId(101);
            travelRequest.setToBeApprovedByHRId(201);
            travelRequest.setRequestRaisedOn(new Date(2023,12,10));
            travelRequest.setFromDate(new Date(2025,1,15));
            travelRequest.setToDate(new Date(2025,1,20));
            travelRequest.setPurposeOfTravel("Business Meeting");
            travelRequest.setRequestStatus("Approve");
            travelRequest.setRequestApprovedOn(new Date(2025,1,10));
            travelRequest.setPriority("Priority 4");
            travelRequest.setLocation(location);

            when(modelMapper.map(Mockito.any(TravelRequestDTO.class),Mockito.eq(TravelRequest.class))).thenReturn(travelRequest);
            when(travelRequestRepository.save(Mockito.any())).thenReturn(travelRequest);

            TravelBudgetAllocation travelBudgetAllocation=new TravelBudgetAllocation();
            travelBudgetAllocation.setApprovedBudget(50000);
            travelBudgetAllocation.setApprovedModeOfTravel("Bus");
            travelBudgetAllocation.setApprovedModeOfTravel("3-Star");
            travelBudgetAllocation.setTravelRequest(travelRequest);

            when(travelBudgetAllocationRepository.save(Mockito.any())).thenReturn(travelBudgetAllocation);

            TravelRequestDetailsDTO travelRequestDetailsDTO=new TravelRequestDetailsDTO();
            travelRequestDetailsDTO.setRequestId(1);
            travelRequestDetailsDTO.setRaisedByEmployeeId(101);
            travelRequestDetailsDTO.setToBeApprovedByHRId(201);
            travelRequestDetailsDTO.setRequestRaisedOn(new Date());
            travelRequestDetailsDTO.setFromDate(new Date(2025,1,15));
            travelRequestDetailsDTO.setToDate(new Date(2025,1,20));
            travelRequestDetailsDTO.setPurposeOfTravel("Business Meeting");
            travelRequestDetailsDTO.setLocationId(1);
            travelRequestDetailsDTO.setLocationName("Delhi");
            travelRequestDetailsDTO.setRequestStatus("Approved");
            travelRequestDetailsDTO.setRequestApprovedOn(new Date(2025,1,10));
            travelRequestDetailsDTO.setPriority("Priority 1");
            travelRequestDetailsDTO.setApprovedBudget(60000);
            travelRequestDetailsDTO.setApprovedModeOfTravel("Air");
            travelRequestDetailsDTO.setApprovedModeOfTravel("5-Star");
            travelRequestDetailsDTO.setEmployeeName("Adrineel");

//            when(modelMapper.map(Mockito.any(TravelRequest.class),Mockito.eq(TravelRequestDTO.class))).thenReturn(travelRequestDTO);

            when(modelMapper.map(Mockito.any(TravelRequest.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);
            when(modelMapper.map(Mockito.any(Location.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);
            when(modelMapper.map(Mockito.any(TravelBudgetAllocation.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);

            TravelRequestDetailsDTO actualTravelRequestDetailsDTO =travelRequestServiceImpl.addTravelRequest(travelRequestDTO);
            assertNotNull(actualTravelRequestDetailsDTO);
        }catch(Exception e){
//            e.printStackTrace();
            //	System.out.println(e);
            assertTrue(true);
        }
    }

    @Test
    public void testAddTravelRequestNegativeExceedingAllowedDays(){
        try{
            TravelRequestDTO travelRequestDTO =new TravelRequestDTO();

            travelRequestDTO.setRequestId(1);
            travelRequestDTO.setRaisedByEmployeeId(101);
            travelRequestDTO.setToBeApprovedByHRId(201);
            travelRequestDTO.setRequestRaisedOn(new Date());
            travelRequestDTO.setFromDate(new Date(2025,1,15));
            travelRequestDTO.setToDate(new Date(2025,1,20));
            travelRequestDTO.setPurposeOfTravel("Business Meeting");
            travelRequestDTO.setRequestStatus("Approved");
            travelRequestDTO.setRequestApprovedOn(new Date(2025,1,10));
            travelRequestDTO.setPriority("Priority 1");
            travelRequestDTO.setLocationId(1);
            travelRequestDTO.setEmployeeName("Adrineel");

            Location location = new Location();
            location.setId(1);
            location.setName("Delhi");

            when(locationRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(location));

            TravelRequest travelRequest=new TravelRequest();

            travelRequest.setRequestId(1);
            travelRequest.setRaisedByEmployeeId(101);
            travelRequest.setToBeApprovedByHRId(201);
            travelRequest.setRequestRaisedOn(new Date());
            travelRequest.setFromDate(new Date(2025,1,15));
            travelRequest.setToDate(new Date(2025,2,20));
            travelRequest.setPurposeOfTravel("Business Meeting");
            travelRequest.setRequestStatus("Approved");
            travelRequest.setRequestApprovedOn(new Date(2025,1,10));
            travelRequest.setPriority("Priority 1");
            travelRequest.setLocation(location);

            when(modelMapper.map(Mockito.any(TravelRequestDTO.class),Mockito.eq(TravelRequest.class))).thenReturn(travelRequest);
            when(travelRequestRepository.save(Mockito.any())).thenReturn(travelRequest);

            TravelBudgetAllocation travelBudgetAllocation=new TravelBudgetAllocation();
            travelBudgetAllocation.setApprovedBudget(50000);
            travelBudgetAllocation.setApprovedModeOfTravel("Bus");
            travelBudgetAllocation.setApprovedModeOfTravel("3-Star");
            travelBudgetAllocation.setTravelRequest(travelRequest);

            when(travelBudgetAllocationRepository.save(Mockito.any())).thenReturn(travelBudgetAllocation);

            TravelRequestDetailsDTO travelRequestDetailsDTO=new TravelRequestDetailsDTO();
            travelRequestDetailsDTO.setRequestId(1);
            travelRequestDetailsDTO.setRaisedByEmployeeId(101);
            travelRequestDetailsDTO.setToBeApprovedByHRId(201);
            travelRequestDetailsDTO.setRequestRaisedOn(new Date());
            travelRequestDetailsDTO.setFromDate(new Date(2025,1,15));
            travelRequestDetailsDTO.setToDate(new Date(2025,1,20));
            travelRequestDetailsDTO.setPurposeOfTravel("Business Meeting");
            travelRequestDetailsDTO.setLocationId(1);
            travelRequestDetailsDTO.setLocationName("Delhi");
            travelRequestDetailsDTO.setRequestStatus("Approved");
            travelRequestDetailsDTO.setRequestApprovedOn(new Date(2025,1,10));
            travelRequestDetailsDTO.setPriority("Priority 1");
            travelRequestDetailsDTO.setApprovedBudget(60000);
            travelRequestDetailsDTO.setApprovedModeOfTravel("Air");
            travelRequestDetailsDTO.setApprovedModeOfTravel("5-Star");
            travelRequestDetailsDTO.setEmployeeName("Adrineel");

//            when(modelMapper.map(Mockito.any(TravelRequest.class),Mockito.eq(TravelRequestDTO.class))).thenReturn(travelRequestDTO);

            when(modelMapper.map(Mockito.any(TravelRequest.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);
            when(modelMapper.map(Mockito.any(Location.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);
            when(modelMapper.map(Mockito.any(TravelBudgetAllocation.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);

            TravelRequestDetailsDTO actualTravelRequestDetailsDTO =travelRequestServiceImpl.addTravelRequest(travelRequestDTO);
            assertNotNull(actualTravelRequestDetailsDTO);
        }catch(Exception e){
//            e.printStackTrace();
            //	System.out.println(e);
            assertTrue(true);
        }
    }

    @Test
    public void testAddTravelRequestNegativeWhenLocationIsNotFound(){
        try{
            TravelRequestDTO travelRequestDTO =new TravelRequestDTO();

            travelRequestDTO.setRequestId(1);
            travelRequestDTO.setRaisedByEmployeeId(101);
            travelRequestDTO.setToBeApprovedByHRId(201);
            travelRequestDTO.setRequestRaisedOn(new Date());
            travelRequestDTO.setFromDate(new Date(2025,1,15));
            travelRequestDTO.setToDate(new Date(2025,1,20));
            travelRequestDTO.setPurposeOfTravel("Business Meeting");
            travelRequestDTO.setRequestStatus("Approved");
            travelRequestDTO.setRequestApprovedOn(new Date(2025,1,10));
            travelRequestDTO.setPriority("Priority 1");
            travelRequestDTO.setLocationId(1);
            travelRequestDTO.setEmployeeName("Adrineel");

//            Location location = new Location();
//            location.setId(1);
//            location.setName("Delhi");

            when(locationRepository.findById(Mockito.anyInt())).thenReturn(Optional.empty());

//            TravelRequest travelRequest=new TravelRequest();
//
//            travelRequest.setRequestId(1);
//            travelRequest.setRaisedByEmployeeId(101);
//            travelRequest.setToBeApprovedByHRId(201);
//            travelRequest.setRequestRaisedOn(new Date());
//            travelRequest.setFromDate(new Date(2025,1,15));
//            travelRequest.setToDate(new Date(2025,1,20));
//            travelRequest.setPurposeOfTravel("Business Meeting");
//            travelRequest.setRequestStatus("Approved");
//            travelRequest.setRequestApprovedOn(new Date(2025,1,10));
//            travelRequest.setPriority("Priority 1");
//            travelRequest.setLocation(location);
//
//            when(modelMapper.map(Mockito.any(TravelRequestDTO.class),Mockito.eq(TravelRequest.class))).thenReturn(travelRequest);
//            when(travelRequestRepository.save(Mockito.any())).thenReturn(travelRequest);
//            when(modelMapper.map(Mockito.any(TravelRequest.class),Mockito.eq(TravelRequestDTO.class))).thenReturn(travelRequestDTO);

            TravelRequestDetailsDTO actualTravelRequestDetailsDTO =travelRequestServiceImpl.addTravelRequest(travelRequestDTO);
            assertNotNull(actualTravelRequestDetailsDTO);
        }catch(Exception e){
//            e.printStackTrace();
            assertTrue(true);
        }
    }

    @Test
    public void testGetAllPendingTravelRequestsPositiveOneTravelRequestFoundWhenRequestStatusIsNew(){
        try{
            List<TravelRequest> listTravelRequestMock =mock(List.class);

            when(travelRequestRepository.findByToBeApprovedByHRId(Mockito.anyInt())).thenReturn(listTravelRequestMock);

            Iterator<TravelRequest> iteratorTravelRequestMock =mock(Iterator.class);

            when(listTravelRequestMock.iterator()).thenReturn(iteratorTravelRequestMock);
            when(iteratorTravelRequestMock.hasNext()).thenReturn(true).thenReturn(false);

            TravelRequest travelRequestMock=mock(TravelRequest.class);
            when(iteratorTravelRequestMock.next()).thenReturn(travelRequestMock);

            when(travelRequestMock.getRequestStatus()).thenReturn("New");

            Location locationMock=mock(Location.class);
            when(travelRequestMock.getLocation()).thenReturn(locationMock);

            TravelRequestDTO travelRequestDTOMock =mock(TravelRequestDTO.class);
            when(modelMapper.map(Mockito.any(TravelRequest.class), Mockito.eq(TravelRequestDTO.class))).thenReturn(travelRequestDTOMock);

            List<TravelRequestDTO> travelRequestDTOList =travelRequestServiceImpl.getAllPendingTravelRequests(202);

            assertTrue(travelRequestDTOList.size()==1);
        }catch(Exception e){
//            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllPendingTravelRequestsPositiveMultipleTravelRequestsFoundWhenRequestStatusIsNew(){
        try{
            List<TravelRequest> listTravelRequestMock =mock(List.class);

            when(travelRequestRepository.findByToBeApprovedByHRId(Mockito.anyInt())).thenReturn(listTravelRequestMock);

            Iterator<TravelRequest> iteratorTravelRequestMock =mock(Iterator.class);

            when(listTravelRequestMock.iterator()).thenReturn(iteratorTravelRequestMock);
            when(iteratorTravelRequestMock.hasNext()).thenReturn(true).thenReturn(true).thenReturn(false);

            TravelRequest travelRequestMock=mock(TravelRequest.class);
            when(iteratorTravelRequestMock.next()).thenReturn(travelRequestMock);

            when(travelRequestMock.getRequestStatus()).thenReturn("New");

            Location locationMock=mock(Location.class);
            when(travelRequestMock.getLocation()).thenReturn(locationMock);

            TravelRequestDTO travelRequestDTOMock =mock(TravelRequestDTO.class);
            when(modelMapper.map(Mockito.any(TravelRequest.class), Mockito.eq(TravelRequestDTO.class))).thenReturn(travelRequestDTOMock);

            List<TravelRequestDTO> travelRequestDTOList =travelRequestServiceImpl.getAllPendingTravelRequests(202);

            assertTrue(travelRequestDTOList.size()>1);
        }catch(Exception e){
//            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllPendingTravelRequestsNegativeNoTravelRequestsFound(){
        try{
            List<TravelRequest> listTravelRequestMock =mock(List.class);

            when(travelRequestRepository.findByToBeApprovedByHRId(Mockito.anyInt())).thenReturn(listTravelRequestMock);

            Iterator<TravelRequest> iteratorTravelRequestMock =mock(Iterator.class);

            when(listTravelRequestMock.iterator()).thenReturn(iteratorTravelRequestMock);
            when(iteratorTravelRequestMock.hasNext()).thenReturn(false);

            List<TravelRequestDTO> travelRequestDTOList =travelRequestServiceImpl.getAllPendingTravelRequests(202);

            assertTrue(!travelRequestDTOList.isEmpty());
        }catch(Exception e){
//            e.printStackTrace();
            assertTrue(true);
        }
    }

    @Test
    public void testGetAllPendingTravelRequestsNegativeNoTravelRequestsFoundWithNewRequestStatus(){
        try{
            List<TravelRequest> listTravelRequestMock =mock(List.class);

            when(travelRequestRepository.findByToBeApprovedByHRId(Mockito.anyInt())).thenReturn(listTravelRequestMock);

            Iterator<TravelRequest> iteratorTravelRequestMock =mock(Iterator.class);

            when(listTravelRequestMock.iterator()).thenReturn(iteratorTravelRequestMock);
            when(iteratorTravelRequestMock.hasNext()).thenReturn(true).thenReturn(false);

            TravelRequest travelRequestMock=mock(TravelRequest.class);
            when(iteratorTravelRequestMock.next()).thenReturn(travelRequestMock);

            when(travelRequestMock.getRequestStatus()).thenReturn("Approved");

            List<TravelRequestDTO> travelRequestDTOList =travelRequestServiceImpl.getAllPendingTravelRequests(202);

            assertTrue(!travelRequestDTOList.isEmpty());
        }catch(Exception e){
//            e.printStackTrace();
            assertTrue(true);
        }
    }

    @Test
    public void testGetApprovedTravelRequestDetailsPositiveWhenRequestStatusIsApproved(){
        try{
            TravelRequest travelRequest=new TravelRequest();

            travelRequest.setRequestId(4);
            travelRequest.setRaisedByEmployeeId(104);
            travelRequest.setToBeApprovedByHRId(204);
            travelRequest.setRequestRaisedOn(new Date());
            travelRequest.setFromDate(new Date(2025,2,1));
            travelRequest.setToDate(new Date(2025,2,5));
            travelRequest.setPurposeOfTravel("Project");
            travelRequest.setRequestStatus("Approved");
            travelRequest.setRequestApprovedOn(new Date(2025,1,25));
            travelRequest.setPriority("Priority 3");

            Location location = new Location();
            location.setId(4);
            location.setName("Kolkata");

            travelRequest.setLocation(location);

            when(travelRequestRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(travelRequest));

//            when(travelRequest.getRequestStatus()).thenReturn("Approved");

            TravelBudgetAllocation travelBudgetAllocation=new TravelBudgetAllocation();

            travelBudgetAllocation.setId(4);
            travelBudgetAllocation.setApprovedBudget(75000);
            travelBudgetAllocation.setApprovedModeOfTravel("Air");
            travelBudgetAllocation.setApprovedHotelStarRating("5-Star");
            travelBudgetAllocation.setTravelRequest(travelRequest);

            when(travelBudgetAllocationRepository.findByTravelRequestRequestId(Mockito.anyInt())).thenReturn(Optional.of(travelBudgetAllocation));

            TravelRequestDetailsDTO travelRequestDetailsDTO=new TravelRequestDetailsDTO();
            travelRequestDetailsDTO.setRequestId(4);
            travelRequestDetailsDTO.setRaisedByEmployeeId(104);
            travelRequestDetailsDTO.setToBeApprovedByHRId(204);
            travelRequestDetailsDTO.setRequestRaisedOn(new Date());
            travelRequestDetailsDTO.setFromDate(new Date(2025,2,1));
            travelRequestDetailsDTO.setToDate(new Date(2025,2,5));
            travelRequestDetailsDTO.setPurposeOfTravel("Project");
            travelRequestDetailsDTO.setRequestStatus("Approved");
            travelRequestDetailsDTO.setRequestApprovedOn(new Date(2025,1,25));
            travelRequestDetailsDTO.setPriority("Priority 3");
            travelRequestDetailsDTO.setLocationId(4);
            travelRequestDetailsDTO.setLocationName("Kolkata");
            travelRequestDetailsDTO.setApprovedBudget(75000);
            travelRequestDetailsDTO.setApprovedModeOfTravel("Air");
            travelRequestDetailsDTO.setApprovedHotelStarRating("5-Star");
            travelRequestDetailsDTO.setEmployeeName("Sayan");

            when(modelMapper.map(Mockito.any(TravelRequest.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);
            when(modelMapper.map(Mockito.any(Location.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);
            when(modelMapper.map(Mockito.any(TravelBudgetAllocation.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);

            TravelRequestDetailsDTO actualTravelRequestDetailsDTO=travelRequestServiceImpl.getApprovedTravelRequestDetails(4);
            assertNotNull(actualTravelRequestDetailsDTO);

        }catch(Exception e){
//            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetApprovedTravelRequestDetailsPositiveWhenRequestStatusIsNotApproved(){
        try{
            TravelRequest travelRequest=new TravelRequest();

            travelRequest.setRequestId(3);
            travelRequest.setRaisedByEmployeeId(103);
            travelRequest.setToBeApprovedByHRId(203);
            travelRequest.setRequestRaisedOn(new Date());
            travelRequest.setFromDate(new Date(2025,1,25));
            travelRequest.setToDate(new Date(2025,11,30));
            travelRequest.setPurposeOfTravel("Training");
            travelRequest.setRequestStatus("Rejected");
            travelRequest.setRequestApprovedOn(null);
            travelRequest.setPriority("Priority 3");

            Location location = new Location();
            location.setId(3);
            location.setName("Hyderabad");
            travelRequest.setLocation(location);

            when(travelRequestRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(travelRequest));

            TravelRequestDetailsDTO travelRequestDetailsDTO=new TravelRequestDetailsDTO();
            travelRequestDetailsDTO.setRequestId(3);
            travelRequestDetailsDTO.setRaisedByEmployeeId(103);
            travelRequestDetailsDTO.setToBeApprovedByHRId(203);
            travelRequestDetailsDTO.setRequestRaisedOn(new Date());
            travelRequestDetailsDTO.setFromDate(new Date(2025,1,25));
            travelRequestDetailsDTO.setToDate(new Date(2025,1,30));
            travelRequestDetailsDTO.setPurposeOfTravel("Training");
            travelRequestDetailsDTO.setRequestStatus("Rejected");
            travelRequestDetailsDTO.setRequestApprovedOn(null);
            travelRequestDetailsDTO.setPriority("Priority 3");
            travelRequestDetailsDTO.setLocationId(3);
            travelRequestDetailsDTO.setLocationName("Hyderabad");
            travelRequestDetailsDTO.setEmployeeName("Yash");

            when(modelMapper.map(Mockito.any(TravelRequest.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);
            when(modelMapper.map(Mockito.any(Location.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);

            TravelRequestDetailsDTO actualTravelRequestDetailsDTO=travelRequestServiceImpl.getApprovedTravelRequestDetails(4);
            assertNotNull(actualTravelRequestDetailsDTO);
        }catch(Exception e){
//            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetApprovedTravelRequestDetailsNegativeWhenTravelRequestWithRequestStatusApprovedFoundButTravelBudgetAllocationNotFound(){
        try{
            TravelRequest travelRequest=new TravelRequest();

            travelRequest.setRequestId(4);
            travelRequest.setRaisedByEmployeeId(104);
            travelRequest.setToBeApprovedByHRId(204);
            travelRequest.setRequestRaisedOn(new Date());
            travelRequest.setFromDate(new Date(2025,2,1));
            travelRequest.setToDate(new Date(2025,2,5));
            travelRequest.setPurposeOfTravel("Project");
            travelRequest.setRequestStatus("Approved");
            travelRequest.setRequestApprovedOn(new Date(2025,1,25));
            travelRequest.setPriority("Priority 3");

            Location location = new Location();
            location.setId(4);
            location.setName("Kolkata");

            travelRequest.setLocation(location);

            when(travelRequestRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(travelRequest));

            when(travelBudgetAllocationRepository.findByTravelRequestRequestId(Mockito.anyInt())).thenReturn(Optional.empty());
            TravelRequestDetailsDTO actualTravelRequestDetailsDTO=travelRequestServiceImpl.getApprovedTravelRequestDetails(4);
            assertNotNull(actualTravelRequestDetailsDTO);

        }catch(Exception e){
//            e.printStackTrace();
            assertTrue(true);
        }
    }

//    @Test
//    public void testGetApprovedTravelRequestDetailsNegativeWhenTravelRequestFoundButRequestStatusIsNotApproved(){
//        try{
//            TravelRequest travelRequest=new TravelRequest();
//
//            travelRequest.setRequestId(3);
//            travelRequest.setRaisedByEmployeeId(103);
//            travelRequest.setToBeApprovedByHRId(203);
//            travelRequest.setRequestRaisedOn(new Date());
//            travelRequest.setFromDate(new Date(2025,1,25));
//            travelRequest.setToDate(new Date(2025,11,30));
//            travelRequest.setPurposeOfTravel("Training");
//            travelRequest.setRequestStatus("Rejected");
//            travelRequest.setRequestApprovedOn(null);
//            travelRequest.setPriority("Priority 3");
//
//            Location location = new Location();
//            location.setId(3);
//            location.setName("Hyderabad");
//
//            when(travelRequestRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(travelRequest));
//
//            TravelRequestDetailsDTO actualTravelRequestDetailsDTO=travelRequestServiceImpl.getApprovedTravelRequestDetails(3);
//            assertNotNull(actualTravelRequestDetailsDTO);
//
//        }catch(Exception e){
////            e.printStackTrace();
//            assertTrue(true);
//        }
//    }

    @Test
    public void testGetApprovedTravelRequestDetailsNegativeWhenTravelRequestNotFound(){
        try{
            when(travelRequestRepository.findById(Mockito.anyInt())).thenReturn(Optional.empty());

            TravelRequestDetailsDTO actualTravelRequestDetailsDTO=travelRequestServiceImpl.getApprovedTravelRequestDetails(4);
            assertNotNull(actualTravelRequestDetailsDTO);

        }catch(Exception e){
//            e.printStackTrace();
            assertTrue(true);
        }
    }

    @Test
    public void testApproveOrRejectTravelRequestPositiveWhenUpdatedRequestStatusIsApproved(){
        try{
            UpdateTravelRequestDTO updateTravelRequestDTO=new UpdateTravelRequestDTO();
            updateTravelRequestDTO.setRequestId(6);
            updateTravelRequestDTO.setRequestStatus("Approved");
            updateTravelRequestDTO.setRequestApprovedOn(new Date(2025,12,20));
            updateTravelRequestDTO.setApprovedModeOfTravel("Air");
            updateTravelRequestDTO.setApprovedHotelStarRating("7-Star");

            TravelRequest travelRequest=new TravelRequest();

            travelRequest.setRequestId(6);
            travelRequest.setRaisedByEmployeeId(106);
            travelRequest.setToBeApprovedByHRId(206);
            travelRequest.setRequestRaisedOn(new Date());
            travelRequest.setFromDate(new Date(2025,1,15));
            travelRequest.setToDate(new Date(2025,1,20));
            travelRequest.setPurposeOfTravel("Workshop");
            travelRequest.setRequestStatus("New");
            travelRequest.setRequestApprovedOn(null);
            travelRequest.setPriority("Priority 1");

            Location location = new Location();
            location.setId(2);
            location.setName("Mumbai");

            travelRequest.setLocation(location);

            when(travelRequestRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(travelRequest));

            TravelBudgetAllocation travelBudgetAllocation=new TravelBudgetAllocation();
            travelBudgetAllocation.setApprovedBudget(0);
            travelBudgetAllocation.setApprovedModeOfTravel(null);
            travelBudgetAllocation.setApprovedHotelStarRating(null);
            travelBudgetAllocation.setTravelRequest(travelRequest);

            when(travelBudgetAllocationRepository.findByTravelRequestRequestId(Mockito.anyInt())).thenReturn(Optional.of(travelBudgetAllocation));

            when(employeeService.getEmployeeGrade(Mockito.anyInt())).thenReturn("Grade 3");
            when(employeeService.getEmployeeRole(Mockito.anyInt())).thenReturn("HR");

            TravelRequest updatedTravelRequest=new TravelRequest();
            updatedTravelRequest.setRequestId(6);
            updatedTravelRequest.setRaisedByEmployeeId(106);
            updatedTravelRequest.setToBeApprovedByHRId(206);
            updatedTravelRequest.setRequestRaisedOn(new Date());
            updatedTravelRequest.setFromDate(new Date(2025,1,15));
            updatedTravelRequest.setToDate(new Date(2025,1,20));
            updatedTravelRequest.setPurposeOfTravel("Workshop");
            updatedTravelRequest.setRequestStatus("Approved");
            updatedTravelRequest.setRequestApprovedOn(new Date(2025,12,20));
            updatedTravelRequest.setPriority("Priority 1");
            updatedTravelRequest.setLocation(location);

            when(travelRequestRepository.save(Mockito.any())).thenReturn(updatedTravelRequest);

            TravelBudgetAllocation updatedTravelBudgetAllocation=new TravelBudgetAllocation();
            updatedTravelBudgetAllocation.setApprovedBudget(90000);
            updatedTravelBudgetAllocation.setApprovedModeOfTravel("Air");
            updatedTravelBudgetAllocation.setApprovedHotelStarRating("7-Star");
            updatedTravelBudgetAllocation.setTravelRequest(updatedTravelRequest);

            when(travelBudgetAllocationRepository.save(Mockito.any())).thenReturn(updatedTravelBudgetAllocation);

            TravelRequestDetailsDTO travelRequestDetailsDTO=new TravelRequestDetailsDTO();
            travelRequestDetailsDTO.setRequestId(6);
            travelRequestDetailsDTO.setRaisedByEmployeeId(106);
            travelRequestDetailsDTO.setToBeApprovedByHRId(206);
            travelRequestDetailsDTO.setRequestRaisedOn(new Date());
            travelRequestDetailsDTO.setFromDate(new Date(2025,1,15));
            travelRequestDetailsDTO.setToDate(new Date(2025,1,20));
            travelRequestDetailsDTO.setPurposeOfTravel("Workshop");
            travelRequestDetailsDTO.setRequestStatus("Approved");
            travelRequestDetailsDTO.setRequestApprovedOn(new Date(2025,12,20));
            travelRequestDetailsDTO.setPriority("Priority 1");
            travelRequestDetailsDTO.setLocationId(2);
            travelRequestDetailsDTO.setLocationName("Mumbai");
            travelRequestDetailsDTO.setApprovedBudget(90000);
            travelRequestDetailsDTO.setApprovedModeOfTravel("Air");
            travelRequestDetailsDTO.setApprovedHotelStarRating("7-Star");
            travelRequestDetailsDTO.setEmployeeName("Jigisha");

            when(modelMapper.map(Mockito.any(TravelRequest.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);
            when(modelMapper.map(Mockito.any(Location.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);
            when(modelMapper.map(Mockito.any(TravelBudgetAllocation.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);

            TravelRequestDetailsDTO actualTravelRequestDetailsDTO=travelRequestServiceImpl.approveOrRejectTravelRequest(6,updateTravelRequestDTO);
            assertNotNull(actualTravelRequestDetailsDTO);
        }catch(Exception e){
//            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testApproveOrRejectTravelRequestPositiveWhenUpdatedRequestStatusIsRejected(){
        try{
            UpdateTravelRequestDTO updateTravelRequestDTO=new UpdateTravelRequestDTO();
            updateTravelRequestDTO.setRequestId(7);
            updateTravelRequestDTO.setRequestStatus("Rejected");
//            updateTravelRequestDTO.setRequestApprovedOn(0);
//            updateTravelRequestDTO.setApprovedModeOfTravel(null);
//            updateTravelRequestDTO.setApprovedHotelStarRating(null);

            TravelRequest travelRequest=new TravelRequest();

            travelRequest.setRequestId(7);
            travelRequest.setRaisedByEmployeeId(107);
            travelRequest.setToBeApprovedByHRId(207);
            travelRequest.setRequestRaisedOn(new Date());
            travelRequest.setFromDate(new Date(2025,1,20));
            travelRequest.setToDate(new Date(2025,1,25));
            travelRequest.setPurposeOfTravel("Seminar");
            travelRequest.setRequestStatus("New");
            travelRequest.setRequestApprovedOn(null);
            travelRequest.setPriority("Priority 2");

            Location location = new Location();
            location.setId(3);
            location.setName("Hyderabd");

            travelRequest.setLocation(location);

            when(travelRequestRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(travelRequest));

            TravelBudgetAllocation travelBudgetAllocation=new TravelBudgetAllocation();
            travelBudgetAllocation.setApprovedBudget(0);
            travelBudgetAllocation.setApprovedModeOfTravel(null);
            travelBudgetAllocation.setApprovedHotelStarRating(null);
            travelBudgetAllocation.setTravelRequest(travelRequest);

            when(travelBudgetAllocationRepository.findByTravelRequestRequestId(Mockito.anyInt())).thenReturn(Optional.of(travelBudgetAllocation));

//            when(employeeService.getEmployeeGrade(Mockito.anyInt())).thenReturn("Grade 3");
//            when(employeeService.getEmployeeRole(Mockito.anyInt())).thenReturn("HR");

            TravelRequest updatedTravelRequest=new TravelRequest();
            updatedTravelRequest.setRequestId(7);
            updatedTravelRequest.setRaisedByEmployeeId(107);
            updatedTravelRequest.setToBeApprovedByHRId(207);
            updatedTravelRequest.setRequestRaisedOn(new Date());
            updatedTravelRequest.setFromDate(new Date(2025,1,20));
            updatedTravelRequest.setToDate(new Date(2025,1,25));
            updatedTravelRequest.setPurposeOfTravel("Seminar");
            updatedTravelRequest.setRequestStatus("Rejected");
            updatedTravelRequest.setRequestApprovedOn(null);
            updatedTravelRequest.setPriority("Priority 2");
            updatedTravelRequest.setLocation(location);

            when(travelRequestRepository.save(Mockito.any())).thenReturn(updatedTravelRequest);

//            TravelBudgetAllocation updatedTravelBudgetAllocation=new TravelBudgetAllocation();
//            updatedTravelBudgetAllocation.setApprovedBudget(90000);
//            updatedTravelBudgetAllocation.setApprovedModeOfTravel("Air");
//            updatedTravelBudgetAllocation.setApprovedHotelStarRating("7-Star");
//            updatedTravelBudgetAllocation.setTravelRequest(updatedTravelRequest);

//            when(travelBudgetAllocationRepository.save(Mockito.any())).thenReturn(updatedTravelBudgetAllocation);

            TravelRequestDetailsDTO travelRequestDetailsDTO=new TravelRequestDetailsDTO();
            travelRequestDetailsDTO.setRequestId(7);
            travelRequestDetailsDTO.setRaisedByEmployeeId(107);
            travelRequestDetailsDTO.setToBeApprovedByHRId(207);
            travelRequestDetailsDTO.setRequestRaisedOn(new Date());
            travelRequestDetailsDTO.setFromDate(new Date(2025,1,15));
            travelRequestDetailsDTO.setToDate(new Date(2025,1,20));
            travelRequestDetailsDTO.setPurposeOfTravel("Seminar");
            travelRequestDetailsDTO.setRequestStatus("Rejected");
            travelRequestDetailsDTO.setRequestApprovedOn(null);
            travelRequestDetailsDTO.setPriority("Priority 2");
            travelRequestDetailsDTO.setLocationId(3);
            travelRequestDetailsDTO.setLocationName("Hyderabad");
            travelRequestDetailsDTO.setApprovedBudget(0);
            travelRequestDetailsDTO.setApprovedModeOfTravel(null);
            travelRequestDetailsDTO.setApprovedHotelStarRating(null);
            travelRequestDetailsDTO.setEmployeeName("Debasmita");

            when(modelMapper.map(Mockito.any(TravelRequest.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);
            when(modelMapper.map(Mockito.any(Location.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);
            when(modelMapper.map(Mockito.any(TravelBudgetAllocation.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);

            TravelRequestDetailsDTO actualTravelRequestDetailsDTO=travelRequestServiceImpl.approveOrRejectTravelRequest(7,updateTravelRequestDTO);
            assertNotNull(actualTravelRequestDetailsDTO);
        }catch(Exception e){
//            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testApproveOrRejectTravelRequestNegativeWhenUpdatedRequestStatusIsApprovedButEmployeeGradeIsInvalid(){
        try{
            UpdateTravelRequestDTO updateTravelRequestDTO=new UpdateTravelRequestDTO();
            updateTravelRequestDTO.setRequestId(6);
            updateTravelRequestDTO.setRequestStatus("Approved");
            updateTravelRequestDTO.setRequestApprovedOn(new Date(2025,12,20));
            updateTravelRequestDTO.setApprovedModeOfTravel("Air");
            updateTravelRequestDTO.setApprovedHotelStarRating("7-Star");

            TravelRequest travelRequest=new TravelRequest();

            travelRequest.setRequestId(6);
            travelRequest.setRaisedByEmployeeId(106);
            travelRequest.setToBeApprovedByHRId(206);
            travelRequest.setRequestRaisedOn(new Date());
            travelRequest.setFromDate(new Date(2025,1,15));
            travelRequest.setToDate(new Date(2025,1,20));
            travelRequest.setPurposeOfTravel("Workshop");
            travelRequest.setRequestStatus("New");
            travelRequest.setRequestApprovedOn(null);
            travelRequest.setPriority("Priority 1");

            Location location = new Location();
            location.setId(2);
            location.setName("Mumbai");

            travelRequest.setLocation(location);

            when(travelRequestRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(travelRequest));

            TravelBudgetAllocation travelBudgetAllocation=new TravelBudgetAllocation();
            travelBudgetAllocation.setApprovedBudget(0);
            travelBudgetAllocation.setApprovedModeOfTravel(null);
            travelBudgetAllocation.setApprovedHotelStarRating(null);
            travelBudgetAllocation.setTravelRequest(travelRequest);

            when(travelBudgetAllocationRepository.findByTravelRequestRequestId(Mockito.anyInt())).thenReturn(Optional.of(travelBudgetAllocation));

            when(employeeService.getEmployeeGrade(Mockito.anyInt())).thenReturn("Grade 4");
//            when(employeeService.getEmployeeRole(Mockito.anyInt())).thenReturn("HR");

//            TravelRequest updatedTravelRequest=new TravelRequest();
//            updatedTravelRequest.setRequestId(6);
//            updatedTravelRequest.setRaisedByEmployeeId(106);
//            updatedTravelRequest.setToBeApprovedByHRId(206);
//            updatedTravelRequest.setRequestRaisedOn(new Date());
//            updatedTravelRequest.setFromDate(new Date(2025,1,15));
//            updatedTravelRequest.setToDate(new Date(2025,1,20));
//            updatedTravelRequest.setPurposeOfTravel("Workshop");
//            updatedTravelRequest.setRequestStatus("Approved");
//            updatedTravelRequest.setRequestApprovedOn(new Date(2025,12,20));
//            updatedTravelRequest.setPriority("Priority 1");
//            updatedTravelRequest.setLocation(location);

//            when(travelRequestRepository.save(Mockito.any())).thenReturn(updatedTravelRequest);

//            TravelBudgetAllocation updatedTravelBudgetAllocation=new TravelBudgetAllocation();
//            updatedTravelBudgetAllocation.setApprovedBudget(90000);
//            updatedTravelBudgetAllocation.setApprovedModeOfTravel("Air");
//            updatedTravelBudgetAllocation.setApprovedHotelStarRating("7-Star");
//            updatedTravelBudgetAllocation.setTravelRequest(updatedTravelRequest);

//            when(travelBudgetAllocationRepository.save(Mockito.any())).thenReturn(updatedTravelBudgetAllocation);

//            TravelRequestDetailsDTO travelRequestDetailsDTO=new TravelRequestDetailsDTO();
//            travelRequestDetailsDTO.setRequestId(6);
//            travelRequestDetailsDTO.setRaisedByEmployeeId(106);
//            travelRequestDetailsDTO.setToBeApprovedByHRId(206);
//            travelRequestDetailsDTO.setRequestRaisedOn(new Date());
//            travelRequestDetailsDTO.setFromDate(new Date(2025,1,15));
//            travelRequestDetailsDTO.setToDate(new Date(2025,1,20));
//            travelRequestDetailsDTO.setPurposeOfTravel("Workshop");
//            travelRequestDetailsDTO.setRequestStatus("Approved");
//            travelRequestDetailsDTO.setRequestApprovedOn(new Date(2025,12,20));
//            travelRequestDetailsDTO.setPriority("Priority 1");
//            travelRequestDetailsDTO.setLocationId(2);
//            travelRequestDetailsDTO.setLocationName("Mumbai");
//            travelRequestDetailsDTO.setApprovedBudget(90000);
//            travelRequestDetailsDTO.setApprovedModeOfTravel("Air");
//            travelRequestDetailsDTO.setApprovedHotelStarRating("7-Star");
//
//            when(modelMapper.map(Mockito.any(TravelRequest.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);
//            when(modelMapper.map(Mockito.any(Location.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);
//            when(modelMapper.map(Mockito.any(TravelBudgetAllocation.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);

            TravelRequestDetailsDTO actualTravelRequestDetailsDTO=travelRequestServiceImpl.approveOrRejectTravelRequest(6,updateTravelRequestDTO);
            assertNotNull(actualTravelRequestDetailsDTO);
        }catch(Exception e){
//            e.printStackTrace();
            assertTrue(true);
        }
    }

    @Test
    public void testApproveOrRejectTravelRequestNegativeWhenUpdatedRequestStatusIsApprovedButHotelStarRatingISInvalidForHR(){
        try{
            UpdateTravelRequestDTO updateTravelRequestDTO=new UpdateTravelRequestDTO();
            updateTravelRequestDTO.setRequestId(6);
            updateTravelRequestDTO.setRequestStatus("Approved");
            updateTravelRequestDTO.setRequestApprovedOn(new Date(2025,12,20));
            updateTravelRequestDTO.setApprovedModeOfTravel("Air");
            updateTravelRequestDTO.setApprovedHotelStarRating("3-Star");

            TravelRequest travelRequest=new TravelRequest();

            travelRequest.setRequestId(6);
            travelRequest.setRaisedByEmployeeId(106);
            travelRequest.setToBeApprovedByHRId(206);
            travelRequest.setRequestRaisedOn(new Date());
            travelRequest.setFromDate(new Date(2025,1,15));
            travelRequest.setToDate(new Date(2025,1,20));
            travelRequest.setPurposeOfTravel("Workshop");
            travelRequest.setRequestStatus("New");
            travelRequest.setRequestApprovedOn(null);
            travelRequest.setPriority("Priority 1");

            Location location = new Location();
            location.setId(2);
            location.setName("Mumbai");

            travelRequest.setLocation(location);

            when(travelRequestRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(travelRequest));

            TravelBudgetAllocation travelBudgetAllocation=new TravelBudgetAllocation();
            travelBudgetAllocation.setApprovedBudget(0);
            travelBudgetAllocation.setApprovedModeOfTravel(null);
            travelBudgetAllocation.setApprovedHotelStarRating(null);
            travelBudgetAllocation.setTravelRequest(travelRequest);

            when(travelBudgetAllocationRepository.findByTravelRequestRequestId(Mockito.anyInt())).thenReturn(Optional.of(travelBudgetAllocation));

            when(employeeService.getEmployeeGrade(Mockito.anyInt())).thenReturn("Grade 3");
            when(employeeService.getEmployeeRole(Mockito.anyInt())).thenReturn("HR");

//            TravelRequest updatedTravelRequest=new TravelRequest();
//            updatedTravelRequest.setRequestId(6);
//            updatedTravelRequest.setRaisedByEmployeeId(106);
//            updatedTravelRequest.setToBeApprovedByHRId(206);
//            updatedTravelRequest.setRequestRaisedOn(new Date());
//            updatedTravelRequest.setFromDate(new Date(2025,1,15));
//            updatedTravelRequest.setToDate(new Date(2025,1,20));
//            updatedTravelRequest.setPurposeOfTravel("Workshop");
//            updatedTravelRequest.setRequestStatus("Approved");
//            updatedTravelRequest.setRequestApprovedOn(new Date(2025,12,20));
//            updatedTravelRequest.setPriority("Priority 1");
//            updatedTravelRequest.setLocation(location);

//            when(travelRequestRepository.save(Mockito.any())).thenReturn(updatedTravelRequest);

//            TravelBudgetAllocation updatedTravelBudgetAllocation=new TravelBudgetAllocation();
//            updatedTravelBudgetAllocation.setApprovedBudget(90000);
//            updatedTravelBudgetAllocation.setApprovedModeOfTravel("Air");
//            updatedTravelBudgetAllocation.setApprovedHotelStarRating("7-Star");
//            updatedTravelBudgetAllocation.setTravelRequest(updatedTravelRequest);

//            when(travelBudgetAllocationRepository.save(Mockito.any())).thenReturn(updatedTravelBudgetAllocation);

//            TravelRequestDetailsDTO travelRequestDetailsDTO=new TravelRequestDetailsDTO();
//            travelRequestDetailsDTO.setRequestId(6);
//            travelRequestDetailsDTO.setRaisedByEmployeeId(106);
//            travelRequestDetailsDTO.setToBeApprovedByHRId(206);
//            travelRequestDetailsDTO.setRequestRaisedOn(new Date());
//            travelRequestDetailsDTO.setFromDate(new Date(2025,1,15));
//            travelRequestDetailsDTO.setToDate(new Date(2025,1,20));
//            travelRequestDetailsDTO.setPurposeOfTravel("Workshop");
//            travelRequestDetailsDTO.setRequestStatus("Approved");
//            travelRequestDetailsDTO.setRequestApprovedOn(new Date(2025,12,20));
//            travelRequestDetailsDTO.setPriority("Priority 1");
//            travelRequestDetailsDTO.setLocationId(2);
//            travelRequestDetailsDTO.setLocationName("Mumbai");
//            travelRequestDetailsDTO.setApprovedBudget(90000);
//            travelRequestDetailsDTO.setApprovedModeOfTravel("Air");
//            travelRequestDetailsDTO.setApprovedHotelStarRating("7-Star");
//
//            when(modelMapper.map(Mockito.any(TravelRequest.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);
//            when(modelMapper.map(Mockito.any(Location.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);
//            when(modelMapper.map(Mockito.any(TravelBudgetAllocation.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);

            TravelRequestDetailsDTO actualTravelRequestDetailsDTO=travelRequestServiceImpl.approveOrRejectTravelRequest(6,updateTravelRequestDTO);
            assertNotNull(actualTravelRequestDetailsDTO);
        }catch(Exception e){
//            e.printStackTrace();
            assertTrue(true);
        }
    }

    @Test
    public void testApproveOrRejectTravelRequestNegativeWhenUpdatedRequestStatusIsApprovedButHotelStarRatingISInvalidForNonHR(){
        try{
            UpdateTravelRequestDTO updateTravelRequestDTO=new UpdateTravelRequestDTO();
            updateTravelRequestDTO.setRequestId(6);
            updateTravelRequestDTO.setRequestStatus("Approved");
            updateTravelRequestDTO.setRequestApprovedOn(new Date(2025,12,20));
            updateTravelRequestDTO.setApprovedModeOfTravel("Air");
            updateTravelRequestDTO.setApprovedHotelStarRating("7-Star");

            TravelRequest travelRequest=new TravelRequest();

            travelRequest.setRequestId(6);
            travelRequest.setRaisedByEmployeeId(106);
            travelRequest.setToBeApprovedByHRId(206);
            travelRequest.setRequestRaisedOn(new Date());
            travelRequest.setFromDate(new Date(2025,1,15));
            travelRequest.setToDate(new Date(2025,1,20));
            travelRequest.setPurposeOfTravel("Workshop");
            travelRequest.setRequestStatus("New");
            travelRequest.setRequestApprovedOn(null);
            travelRequest.setPriority("Priority 1");

            Location location = new Location();
            location.setId(2);
            location.setName("Mumbai");

            travelRequest.setLocation(location);

            when(travelRequestRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(travelRequest));

            TravelBudgetAllocation travelBudgetAllocation=new TravelBudgetAllocation();
            travelBudgetAllocation.setApprovedBudget(0);
            travelBudgetAllocation.setApprovedModeOfTravel(null);
            travelBudgetAllocation.setApprovedHotelStarRating(null);
            travelBudgetAllocation.setTravelRequest(travelRequest);

            when(travelBudgetAllocationRepository.findByTravelRequestRequestId(Mockito.anyInt())).thenReturn(Optional.of(travelBudgetAllocation));

            when(employeeService.getEmployeeGrade(Mockito.anyInt())).thenReturn("Grade 2");
            when(employeeService.getEmployeeRole(Mockito.anyInt())).thenReturn("TravelDeskExec");

//            TravelRequest updatedTravelRequest=new TravelRequest();
//            updatedTravelRequest.setRequestId(6);
//            updatedTravelRequest.setRaisedByEmployeeId(106);
//            updatedTravelRequest.setToBeApprovedByHRId(206);
//            updatedTravelRequest.setRequestRaisedOn(new Date());
//            updatedTravelRequest.setFromDate(new Date(2025,1,15));
//            updatedTravelRequest.setToDate(new Date(2025,1,20));
//            updatedTravelRequest.setPurposeOfTravel("Workshop");
//            updatedTravelRequest.setRequestStatus("Approved");
//            updatedTravelRequest.setRequestApprovedOn(new Date(2025,12,20));
//            updatedTravelRequest.setPriority("Priority 1");
//            updatedTravelRequest.setLocation(location);

//            when(travelRequestRepository.save(Mockito.any())).thenReturn(updatedTravelRequest);

//            TravelBudgetAllocation updatedTravelBudgetAllocation=new TravelBudgetAllocation();
//            updatedTravelBudgetAllocation.setApprovedBudget(90000);
//            updatedTravelBudgetAllocation.setApprovedModeOfTravel("Air");
//            updatedTravelBudgetAllocation.setApprovedHotelStarRating("7-Star");
//            updatedTravelBudgetAllocation.setTravelRequest(updatedTravelRequest);

//            when(travelBudgetAllocationRepository.save(Mockito.any())).thenReturn(updatedTravelBudgetAllocation);

//            TravelRequestDetailsDTO travelRequestDetailsDTO=new TravelRequestDetailsDTO();
//            travelRequestDetailsDTO.setRequestId(6);
//            travelRequestDetailsDTO.setRaisedByEmployeeId(106);
//            travelRequestDetailsDTO.setToBeApprovedByHRId(206);
//            travelRequestDetailsDTO.setRequestRaisedOn(new Date());
//            travelRequestDetailsDTO.setFromDate(new Date(2025,1,15));
//            travelRequestDetailsDTO.setToDate(new Date(2025,1,20));
//            travelRequestDetailsDTO.setPurposeOfTravel("Workshop");
//            travelRequestDetailsDTO.setRequestStatus("Approved");
//            travelRequestDetailsDTO.setRequestApprovedOn(new Date(2025,12,20));
//            travelRequestDetailsDTO.setPriority("Priority 1");
//            travelRequestDetailsDTO.setLocationId(2);
//            travelRequestDetailsDTO.setLocationName("Mumbai");
//            travelRequestDetailsDTO.setApprovedBudget(90000);
//            travelRequestDetailsDTO.setApprovedModeOfTravel("Air");
//            travelRequestDetailsDTO.setApprovedHotelStarRating("7-Star");
//
//            when(modelMapper.map(Mockito.any(TravelRequest.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);
//            when(modelMapper.map(Mockito.any(Location.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);
//            when(modelMapper.map(Mockito.any(TravelBudgetAllocation.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);

            TravelRequestDetailsDTO actualTravelRequestDetailsDTO=travelRequestServiceImpl.approveOrRejectTravelRequest(6,updateTravelRequestDTO);
            assertNotNull(actualTravelRequestDetailsDTO);
        }catch(Exception e){
//            e.printStackTrace();
            assertTrue(true);
        }
    }

    @Test
    public void testApproveOrRejectTravelRequestNegativeWhenTravelRequestFoundButTravelBudgetAllocationNotFound(){
        try{
            UpdateTravelRequestDTO updateTravelRequestDTO=new UpdateTravelRequestDTO();
            updateTravelRequestDTO.setRequestId(6);
            updateTravelRequestDTO.setRequestStatus("Approved");
            updateTravelRequestDTO.setRequestApprovedOn(new Date(2025,12,20));
            updateTravelRequestDTO.setApprovedModeOfTravel("Air");
            updateTravelRequestDTO.setApprovedHotelStarRating("7-Star");

            TravelRequest travelRequest=new TravelRequest();

            travelRequest.setRequestId(6);
            travelRequest.setRaisedByEmployeeId(106);
            travelRequest.setToBeApprovedByHRId(206);
            travelRequest.setRequestRaisedOn(new Date());
            travelRequest.setFromDate(new Date(2025,1,15));
            travelRequest.setToDate(new Date(2025,1,20));
            travelRequest.setPurposeOfTravel("Workshop");
            travelRequest.setRequestStatus("New");
            travelRequest.setRequestApprovedOn(null);
            travelRequest.setPriority("Priority 1");

            Location location = new Location();
            location.setId(2);
            location.setName("Mumbai");

            travelRequest.setLocation(location);

            when(travelRequestRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(travelRequest));

//            TravelBudgetAllocation travelBudgetAllocation=new TravelBudgetAllocation();
//            travelBudgetAllocation.setApprovedBudget(0);
//            travelBudgetAllocation.setApprovedModeOfTravel(null);
//            travelBudgetAllocation.setApprovedHotelStarRating(null);
//            travelBudgetAllocation.setTravelRequest(travelRequest);

            when(travelBudgetAllocationRepository.findByTravelRequestRequestId(Mockito.anyInt())).thenReturn(Optional.empty());

//            when(employeeService.getEmployeeGrade(Mockito.anyInt())).thenReturn("Grade 3");
//            when(employeeService.getEmployeeRole(Mockito.anyInt())).thenReturn("HR");

//            TravelRequest updatedTravelRequest=new TravelRequest();
//            updatedTravelRequest.setRequestId(6);
//            updatedTravelRequest.setRaisedByEmployeeId(106);
//            updatedTravelRequest.setToBeApprovedByHRId(206);
//            updatedTravelRequest.setRequestRaisedOn(new Date());
//            updatedTravelRequest.setFromDate(new Date(2025,1,15));
//            updatedTravelRequest.setToDate(new Date(2025,1,20));
//            updatedTravelRequest.setPurposeOfTravel("Workshop");
//            updatedTravelRequest.setRequestStatus("Approved");
//            updatedTravelRequest.setRequestApprovedOn(new Date(2025,12,20));
//            updatedTravelRequest.setPriority("Priority 1");
//            updatedTravelRequest.setLocation(location);

//            when(travelRequestRepository.save(Mockito.any())).thenReturn(updatedTravelRequest);

//            TravelBudgetAllocation updatedTravelBudgetAllocation=new TravelBudgetAllocation();
//            updatedTravelBudgetAllocation.setApprovedBudget(90000);
//            updatedTravelBudgetAllocation.setApprovedModeOfTravel("Air");
//            updatedTravelBudgetAllocation.setApprovedHotelStarRating("7-Star");
//            updatedTravelBudgetAllocation.setTravelRequest(updatedTravelRequest);

//            when(travelBudgetAllocationRepository.save(Mockito.any())).thenReturn(updatedTravelBudgetAllocation);

//            TravelRequestDetailsDTO travelRequestDetailsDTO=new TravelRequestDetailsDTO();
//            travelRequestDetailsDTO.setRequestId(6);
//            travelRequestDetailsDTO.setRaisedByEmployeeId(106);
//            travelRequestDetailsDTO.setToBeApprovedByHRId(206);
//            travelRequestDetailsDTO.setRequestRaisedOn(new Date());
//            travelRequestDetailsDTO.setFromDate(new Date(2025,1,15));
//            travelRequestDetailsDTO.setToDate(new Date(2025,1,20));
//            travelRequestDetailsDTO.setPurposeOfTravel("Workshop");
//            travelRequestDetailsDTO.setRequestStatus("Approved");
//            travelRequestDetailsDTO.setRequestApprovedOn(new Date(2025,12,20));
//            travelRequestDetailsDTO.setPriority("Priority 1");
//            travelRequestDetailsDTO.setLocationId(2);
//            travelRequestDetailsDTO.setLocationName("Mumbai");
//            travelRequestDetailsDTO.setApprovedBudget(90000);
//            travelRequestDetailsDTO.setApprovedModeOfTravel("Air");
//            travelRequestDetailsDTO.setApprovedHotelStarRating("7-Star");
//
//            when(modelMapper.map(Mockito.any(TravelRequest.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);
//            when(modelMapper.map(Mockito.any(Location.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);
//            when(modelMapper.map(Mockito.any(TravelBudgetAllocation.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);

            TravelRequestDetailsDTO actualTravelRequestDetailsDTO=travelRequestServiceImpl.approveOrRejectTravelRequest(6,updateTravelRequestDTO);
            assertNotNull(actualTravelRequestDetailsDTO);
        }catch(Exception e){
//            e.printStackTrace();
            assertTrue(true);
        }
    }

    @Test
    public void testApproveOrRejectTravelRequestNegativeWhenTravelRequestNotFound(){
        try{
            UpdateTravelRequestDTO updateTravelRequestDTO=new UpdateTravelRequestDTO();
            updateTravelRequestDTO.setRequestId(6);
            updateTravelRequestDTO.setRequestStatus("Approved");
            updateTravelRequestDTO.setRequestApprovedOn(new Date(2025,12,20));
            updateTravelRequestDTO.setApprovedModeOfTravel("Air");
            updateTravelRequestDTO.setApprovedHotelStarRating("7-Star");

//            TravelRequest travelRequest=new TravelRequest();
//
//            travelRequest.setRequestId(6);
//            travelRequest.setRaisedByEmployeeId(106);
//            travelRequest.setToBeApprovedByHRId(206);
//            travelRequest.setRequestRaisedOn(new Date());
//            travelRequest.setFromDate(new Date(2025,1,15));
//            travelRequest.setToDate(new Date(2025,1,20));
//            travelRequest.setPurposeOfTravel("Workshop");
//            travelRequest.setRequestStatus("New");
//            travelRequest.setRequestApprovedOn(null);
//            travelRequest.setPriority("Priority 1");
//
//            Location location = new Location();
//            location.setId(2);
//            location.setName("Mumbai");
//
//            travelRequest.setLocation(location);

            when(travelRequestRepository.findById(Mockito.anyInt())).thenReturn(Optional.empty());

//            TravelBudgetAllocation travelBudgetAllocation=new TravelBudgetAllocation();
//            travelBudgetAllocation.setApprovedBudget(0);
//            travelBudgetAllocation.setApprovedModeOfTravel(null);
//            travelBudgetAllocation.setApprovedHotelStarRating(null);
//            travelBudgetAllocation.setTravelRequest(travelRequest);

            when(travelBudgetAllocationRepository.findByTravelRequestRequestId(Mockito.anyInt())).thenReturn(Optional.empty());

//            when(employeeService.getEmployeeGrade(Mockito.anyInt())).thenReturn("Grade 3");
//            when(employeeService.getEmployeeRole(Mockito.anyInt())).thenReturn("HR");

//            TravelRequest updatedTravelRequest=new TravelRequest();
//            updatedTravelRequest.setRequestId(6);
//            updatedTravelRequest.setRaisedByEmployeeId(106);
//            updatedTravelRequest.setToBeApprovedByHRId(206);
//            updatedTravelRequest.setRequestRaisedOn(new Date());
//            updatedTravelRequest.setFromDate(new Date(2025,1,15));
//            updatedTravelRequest.setToDate(new Date(2025,1,20));
//            updatedTravelRequest.setPurposeOfTravel("Workshop");
//            updatedTravelRequest.setRequestStatus("Approved");
//            updatedTravelRequest.setRequestApprovedOn(new Date(2025,12,20));
//            updatedTravelRequest.setPriority("Priority 1");
//            updatedTravelRequest.setLocation(location);

//            when(travelRequestRepository.save(Mockito.any())).thenReturn(updatedTravelRequest);

//            TravelBudgetAllocation updatedTravelBudgetAllocation=new TravelBudgetAllocation();
//            updatedTravelBudgetAllocation.setApprovedBudget(90000);
//            updatedTravelBudgetAllocation.setApprovedModeOfTravel("Air");
//            updatedTravelBudgetAllocation.setApprovedHotelStarRating("7-Star");
//            updatedTravelBudgetAllocation.setTravelRequest(updatedTravelRequest);

//            when(travelBudgetAllocationRepository.save(Mockito.any())).thenReturn(updatedTravelBudgetAllocation);

//            TravelRequestDetailsDTO travelRequestDetailsDTO=new TravelRequestDetailsDTO();
//            travelRequestDetailsDTO.setRequestId(6);
//            travelRequestDetailsDTO.setRaisedByEmployeeId(106);
//            travelRequestDetailsDTO.setToBeApprovedByHRId(206);
//            travelRequestDetailsDTO.setRequestRaisedOn(new Date());
//            travelRequestDetailsDTO.setFromDate(new Date(2025,1,15));
//            travelRequestDetailsDTO.setToDate(new Date(2025,1,20));
//            travelRequestDetailsDTO.setPurposeOfTravel("Workshop");
//            travelRequestDetailsDTO.setRequestStatus("Approved");
//            travelRequestDetailsDTO.setRequestApprovedOn(new Date(2025,12,20));
//            travelRequestDetailsDTO.setPriority("Priority 1");
//            travelRequestDetailsDTO.setLocationId(2);
//            travelRequestDetailsDTO.setLocationName("Mumbai");
//            travelRequestDetailsDTO.setApprovedBudget(90000);
//            travelRequestDetailsDTO.setApprovedModeOfTravel("Air");
//            travelRequestDetailsDTO.setApprovedHotelStarRating("7-Star");
//
//            when(modelMapper.map(Mockito.any(TravelRequest.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);
//            when(modelMapper.map(Mockito.any(Location.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);
//            when(modelMapper.map(Mockito.any(TravelBudgetAllocation.class), Mockito.eq(TravelRequestDetailsDTO.class))).thenReturn(travelRequestDetailsDTO);

            TravelRequestDetailsDTO actualTravelRequestDetailsDTO=travelRequestServiceImpl.approveOrRejectTravelRequest(6,updateTravelRequestDTO);
            assertNotNull(actualTravelRequestDetailsDTO);
        }catch(Exception e){
//            e.printStackTrace();
            assertTrue(true);
        }
    }

}
