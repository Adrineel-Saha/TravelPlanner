package com.cognizant.employeetraveldesk.travelplanner.test.services;

import com.cognizant.employeetraveldesk.travelplanner.dtos.TravelRequestDTO;
import com.cognizant.employeetraveldesk.travelplanner.services.EmployeeService;
import com.cognizant.employeetraveldesk.travelplanner.services.TravelBudgetAllocationServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

public class TestTravelBudgetAllocationServiceImpl {
    @Mock
    EmployeeService employeeService;

    @InjectMocks
    TravelBudgetAllocationServiceImpl travelBudgetAllocationServiceImpl;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @AfterEach
    void tearDown() throws Exception {

    }

    @Test
    public void testCalculateBudgetPositive(){
        try{
            TravelRequestDTO travelRequestDTO =new TravelRequestDTO();

            travelRequestDTO.setRequestId(1);
            travelRequestDTO.setRaisedByEmployeeId(101);
            travelRequestDTO.setToBeApprovedByHRId(201);
            travelRequestDTO.setRequestRaisedOn(new Date());
            travelRequestDTO.setFromDate(new Date(2025,1,15));
            travelRequestDTO.setToDate(new Date(2025,1,20));
            travelRequestDTO.setPurposeOfTravel("Business Meeting");
            travelRequestDTO.setRequestStatus("Approved");
            travelRequestDTO.setRequestApprovedOn(new Date(2025,1,10));
            travelRequestDTO.setPriority("Priority 1");
            travelRequestDTO.setLocationId(1);
            travelRequestDTO.setEmployeeName("Adrineel");

            when(employeeService.getEmployeeGrade(Mockito.anyInt())).thenReturn("Grade 1");

            int expectedBudget=60000;

            int actualBudget= travelBudgetAllocationServiceImpl.calculateBudget(travelRequestDTO);

            assertEquals(expectedBudget,actualBudget);
        }catch(Exception e){
//            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testCalculateBudgetNegativeWhenTravelRequestIsInvalid(){
        try{
            TravelRequestDTO travelRequestDTO =new TravelRequestDTO();

            travelRequestDTO.setRequestId(1);
            travelRequestDTO.setRaisedByEmployeeId(101);
            travelRequestDTO.setToBeApprovedByHRId(201);
            travelRequestDTO.setRequestRaisedOn(new Date(2023,12,12));
            travelRequestDTO.setFromDate(new Date(2025,1,15));
            travelRequestDTO.setToDate(new Date(2025,1,20));
            travelRequestDTO.setPurposeOfTravel("Business Meeting");
            travelRequestDTO.setRequestStatus("ApprovedRejected");
            travelRequestDTO.setRequestApprovedOn(new Date(2025,1,10));
            travelRequestDTO.setPriority("Priority 4");
            travelRequestDTO.setLocationId(1);
            travelRequestDTO.setEmployeeName("Adrineel");

//            when(employeeService.getEmployeeGrade(Mockito.anyInt())).thenReturn("Grade 1");

//            int expectedBudget=60000;

            travelBudgetAllocationServiceImpl.calculateBudget(travelRequestDTO);

            assertTrue(false);
        }catch(Exception e){
//            e.printStackTrace();
            assertTrue(true);
        }
    }

    @Test
    public void testCalculateBudgetNegativeWhenTravelRequestIsNotApproved(){
        try{
            TravelRequestDTO travelRequestDTO =new TravelRequestDTO();

            travelRequestDTO.setRequestId(1);
            travelRequestDTO.setRaisedByEmployeeId(103);
            travelRequestDTO.setToBeApprovedByHRId(203);
            travelRequestDTO.setRequestRaisedOn(new Date());
            travelRequestDTO.setFromDate(new Date(2025,1,25));
            travelRequestDTO.setToDate(new Date(2025,1,30));
            travelRequestDTO.setPurposeOfTravel("Training");
            travelRequestDTO.setRequestStatus("Rejected");
            travelRequestDTO.setRequestApprovedOn(null);
            travelRequestDTO.setPriority("Priority 3");
            travelRequestDTO.setLocationId(3);
            travelRequestDTO.setEmployeeName("Yash");

//            when(employeeService.getEmployeeGrade(Mockito.anyInt())).thenReturn("Grade 1");

//            int expectedBudget=60000;

            travelBudgetAllocationServiceImpl.calculateBudget(travelRequestDTO);

            assertTrue(false);
        }catch(Exception e){
//            e.printStackTrace();
            assertTrue(true);
        }
    }

    @Test
    public void testCalculateBudgetNegativeWhenTravelRequestIsApprovedButExceedingAllowedDays(){
        try{
            TravelRequestDTO travelRequestDTO =new TravelRequestDTO();

            travelRequestDTO.setRequestId(1);
            travelRequestDTO.setRaisedByEmployeeId(101);
            travelRequestDTO.setToBeApprovedByHRId(201);
            travelRequestDTO.setRequestRaisedOn(new Date());
            travelRequestDTO.setFromDate(new Date(2025,1,15));
            travelRequestDTO.setToDate(new Date(2025,2,20));
            travelRequestDTO.setPurposeOfTravel("Business Meeting");
            travelRequestDTO.setRequestStatus("Approved");
            travelRequestDTO.setRequestApprovedOn(new Date(2025,1,10));
            travelRequestDTO.setPriority("Priority 1");
            travelRequestDTO.setLocationId(1);
            travelRequestDTO.setEmployeeName("Adrineel");

//            when(employeeService.getEmployeeGrade(Mockito.anyInt())).thenReturn("Grade 4");

//            int expectedBudget=60000;

            travelBudgetAllocationServiceImpl.calculateBudget(travelRequestDTO);

            assertTrue(false);
        }catch(Exception e){
            e.printStackTrace();
            assertTrue(true);
        }
    }

    @Test
    public void testCalculateBudgetNegativeWhenTravelRequestIsApprovedButEmployeeGradeIsInvalid(){
        try{
            TravelRequestDTO travelRequestDTO =new TravelRequestDTO();

            travelRequestDTO.setRequestId(1);
            travelRequestDTO.setRaisedByEmployeeId(101);
            travelRequestDTO.setToBeApprovedByHRId(201);
            travelRequestDTO.setRequestRaisedOn(new Date());
            travelRequestDTO.setFromDate(new Date(2025,1,15));
            travelRequestDTO.setToDate(new Date(2025,1,20));
            travelRequestDTO.setPurposeOfTravel("Business Meeting");
            travelRequestDTO.setRequestStatus("Approved");
            travelRequestDTO.setRequestApprovedOn(new Date(2025,1,10));
            travelRequestDTO.setPriority("Priority 1");
            travelRequestDTO.setLocationId(1);
            travelRequestDTO.setEmployeeName("Adrineel");

            when(employeeService.getEmployeeGrade(Mockito.anyInt())).thenReturn("Grade 4");

//            int expectedBudget=60000;

            travelBudgetAllocationServiceImpl.calculateBudget(travelRequestDTO);

            assertTrue(false);
        }catch(Exception e){
//            e.printStackTrace();
            assertTrue(true);
        }
    }
}
