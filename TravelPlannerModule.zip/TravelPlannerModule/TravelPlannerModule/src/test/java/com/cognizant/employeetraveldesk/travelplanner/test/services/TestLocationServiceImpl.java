package com.cognizant.employeetraveldesk.travelplanner.test.services;

import com.cognizant.employeetraveldesk.travelplanner.dtos.LocationDTO;
import com.cognizant.employeetraveldesk.travelplanner.entities.Location;
import com.cognizant.employeetraveldesk.travelplanner.repositories.LocationRepository;
import com.cognizant.employeetraveldesk.travelplanner.services.LocationServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;

import java.util.Iterator;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class TestLocationServiceImpl {
    @Mock
    private LocationRepository locationRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private LocationServiceImpl locationServiceImpl;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @AfterEach
    void tearDown() throws Exception {

    }

    @Test
    public void testGetAllLocationsPositiveOneCustomerFound() {
        try {
            List<Location> listLocationMock =mock(List.class);
            when(locationRepository.findAll()).thenReturn(listLocationMock);
            Iterator<Location> iteratorLocationMock =mock(Iterator.class);

            when(listLocationMock.iterator()).thenReturn(iteratorLocationMock);
            when(iteratorLocationMock.hasNext()).thenReturn(true).thenReturn(false);

            Location locationMock =mock(Location.class);

            when(iteratorLocationMock.next()).thenReturn(locationMock);

            LocationDTO locationDTOMock =mock(LocationDTO.class);

            when(modelMapper.map(Mockito.any(Location.class), Mockito.eq(LocationDTO.class))).thenReturn(locationDTOMock);

            List<LocationDTO> customerDTOList =locationServiceImpl.getAllLocations();
            assertTrue(customerDTOList.size()==1);
        }catch(Exception e) {
            //	System.out.println(e);
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllLocationsPositiveMultipleCustomerFound() {
        try {
            List<Location> listLocationMock =mock(List.class);
            when(locationRepository.findAll()).thenReturn(listLocationMock);
            Iterator<Location> iteratorLocationMock =mock(Iterator.class);

            when(listLocationMock.iterator()).thenReturn(iteratorLocationMock);
            when(iteratorLocationMock.hasNext()).thenReturn(true).thenReturn(true).thenReturn(false);

            Location locationMock =mock(Location.class);

            when(iteratorLocationMock.next()).thenReturn(locationMock);

            LocationDTO locationDTOMock =mock(LocationDTO.class);

            when(modelMapper.map(Mockito.any(Location.class), Mockito.eq(LocationDTO.class))).thenReturn(locationDTOMock);

            List<LocationDTO> customerDTOList =locationServiceImpl.getAllLocations();
            assertTrue(customerDTOList.size()>1);
        }catch(Exception e) {
            //	System.out.println(e);
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllLocationsException() {
        try {
            List<Location> listLocationMock =mock(List.class);
            when(locationRepository.findAll()).thenReturn(listLocationMock);
            Iterator<Location> iteratorLocationMock =mock(Iterator.class);

            when(listLocationMock.iterator()).thenReturn(iteratorLocationMock);
            when(iteratorLocationMock.hasNext()).thenReturn(false);

            Location locationMock =mock(Location.class);

            when(iteratorLocationMock.next()).thenReturn(locationMock);

            LocationDTO locationDTOMock =mock(LocationDTO.class);

            when(modelMapper.map(Mockito.any(Location.class), Mockito.eq(LocationDTO.class))).thenReturn(locationDTOMock);

            List<LocationDTO> customerDTOList =locationServiceImpl.getAllLocations();
            assertTrue(!customerDTOList.isEmpty());
        }catch(Exception e) {
            //	System.out.println(e);
            assertTrue(true);
        }
    }
}
