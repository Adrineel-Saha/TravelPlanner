package com.cognizant.employeetraveldesk.travelplanner.test.controllers;

import com.cognizant.employeetraveldesk.travelplanner.controllers.TravelPlannerController;
import com.cognizant.employeetraveldesk.travelplanner.dtos.LocationDTO;
import com.cognizant.employeetraveldesk.travelplanner.dtos.TravelRequestDTO;
import com.cognizant.employeetraveldesk.travelplanner.dtos.TravelRequestDetailsDTO;
import com.cognizant.employeetraveldesk.travelplanner.dtos.UpdateTravelRequestDTO;
import com.cognizant.employeetraveldesk.travelplanner.main.TravelPlannerModuleApplication;
import com.cognizant.employeetraveldesk.travelplanner.services.LocationService;
import com.cognizant.employeetraveldesk.travelplanner.services.TravelBudgetAllocationService;
import com.cognizant.employeetraveldesk.travelplanner.services.TravelRequestService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@SpringBootTest(classes= TravelPlannerModuleApplication.class)
public class TestTravelPlannerController {
    @Mock
    private LocationService locationService;

    @Mock
    private TravelRequestService travelRequestService;

    @Mock
    private TravelBudgetAllocationService travelBudgetAllocationService;

    @InjectMocks
    private TravelPlannerController travelPlannerController;

    @Autowired
    private LocalValidatorFactoryBean validator;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @AfterEach
    void tearDown() throws Exception {

    }

    @Test
    public void testGetAllLocationsPositiveAssertReturnValue() {
        List<LocationDTO> locationDTOList=new ArrayList<>();

        LocationDTO locationDTO =new LocationDTO();
        locationDTO.setId(1);
        locationDTO.setName("Delhi");

        locationDTOList.add(locationDTO);

        try {
            when(locationService.getAllLocations()).thenReturn(locationDTOList);
            ResponseEntity<List<LocationDTO>> responseEntity=travelPlannerController.getAllLocations();
            List<LocationDTO> actualCustomerDTOList=responseEntity.getBody();
            assertTrue(actualCustomerDTOList.size()>0);
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllLocationsPositiveAssertStatusCode() {
        List<LocationDTO> locationDTOList=new ArrayList<>();

        LocationDTO locationDTO =new LocationDTO();
        locationDTO.setId(1);
        locationDTO.setName("Delhi");

        locationDTOList.add(locationDTO);

        try {
            when(locationService.getAllLocations()).thenReturn(locationDTOList);
            ResponseEntity<List<LocationDTO>> responseEntity=travelPlannerController.getAllLocations();
            assertEquals(200,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllLocationsNegativeAssertReturnValue() {
        List<LocationDTO> locationDTOList=new ArrayList<>();
        try {
            when(locationService.getAllLocations()).thenReturn(locationDTOList);
            ResponseEntity<List<LocationDTO>> responseEntity=travelPlannerController.getAllLocations();
            assertNull(responseEntity.getBody());
        }catch(Exception e) {
//            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllLocationsNegativeAssertStatusCode() {
        List<LocationDTO> locationDTOList=new ArrayList<>();
        try {
            when(locationService.getAllLocations()).thenReturn(locationDTOList);
            ResponseEntity<List<LocationDTO>> responseEntity=travelPlannerController.getAllLocations();
            assertEquals(400,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testAddTravelRequestWhenAddTravelRequestIsValid() {
        TravelRequestDTO travelRequestDTO =new TravelRequestDTO();
        travelRequestDTO.setRequestId(1);
        travelRequestDTO.setRaisedByEmployeeId(101);
        travelRequestDTO.setToBeApprovedByHRId(201);
        travelRequestDTO.setRequestRaisedOn(new Date());
        travelRequestDTO.setFromDate(new Date(2025,1,15));
        travelRequestDTO.setToDate(new Date(2025,1,20));
        travelRequestDTO.setPurposeOfTravel("Business Meeting");
        travelRequestDTO.setRequestStatus("Approved");
        travelRequestDTO.setRequestApprovedOn(new Date(2025,1,10));
        travelRequestDTO.setPriority("Priority 1");
        travelRequestDTO.setLocationId(1);
        travelRequestDTO.setEmployeeName("Adrineel");

        validator.validate(travelRequestDTO).stream().forEach((constraintViolation)->assertNull(constraintViolation));
    }

    @Test
    public void testAddTravelRequestPositiveAssertReturnValue(){
        TravelRequestDTO travelRequestDTO =new TravelRequestDTO();
        travelRequestDTO.setRequestId(1);
        travelRequestDTO.setRaisedByEmployeeId(101);
        travelRequestDTO.setToBeApprovedByHRId(201);
        travelRequestDTO.setRequestRaisedOn(new Date());
        travelRequestDTO.setFromDate(new Date(2025,1,15));
        travelRequestDTO.setToDate(new Date(2025,1,20));
        travelRequestDTO.setPurposeOfTravel("Business Meeting");
        travelRequestDTO.setRequestStatus("Approved");
        travelRequestDTO.setRequestApprovedOn(new Date(2025,1,10));
        travelRequestDTO.setPriority("Priority 1");
        travelRequestDTO.setLocationId(1);
        travelRequestDTO.setEmployeeName("Adrineel");

        TravelRequestDetailsDTO travelRequestDetailsDTO=new TravelRequestDetailsDTO();
        travelRequestDetailsDTO.setRequestId(1);
        travelRequestDetailsDTO.setRaisedByEmployeeId(101);
        travelRequestDetailsDTO.setToBeApprovedByHRId(201);
        travelRequestDetailsDTO.setRequestRaisedOn(new Date());
        travelRequestDetailsDTO.setFromDate(new Date(2025,1,15));
        travelRequestDetailsDTO.setToDate(new Date(2025,1,20));
        travelRequestDetailsDTO.setPurposeOfTravel("Business Meeting");
        travelRequestDetailsDTO.setLocationId(1);
        travelRequestDetailsDTO.setLocationName("Delhi");
        travelRequestDetailsDTO.setRequestStatus("Approved");
        travelRequestDetailsDTO.setRequestApprovedOn(new Date(2025,1,10));
        travelRequestDetailsDTO.setPriority("Priority 1");
        travelRequestDetailsDTO.setApprovedBudget(60000);
        travelRequestDetailsDTO.setApprovedModeOfTravel("Air");
        travelRequestDetailsDTO.setApprovedModeOfTravel("5-Star");
        travelRequestDetailsDTO.setEmployeeName("Adrineel");

        try {
            when(travelRequestService.addTravelRequest(Mockito.any())).thenReturn(travelRequestDetailsDTO);
            ResponseEntity<Integer> responseEntity=travelPlannerController.addTravelRequest(travelRequestDTO);
//            LoanAppDTO actualLoanAppDTO =responseEntity.getBody();
            assertNotNull(responseEntity.getBody());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testAddTravelRequestPositiveAssertStatusCode(){
        TravelRequestDTO travelRequestDTO =new TravelRequestDTO();
        travelRequestDTO.setRequestId(1);
        travelRequestDTO.setRaisedByEmployeeId(101);
        travelRequestDTO.setToBeApprovedByHRId(201);
        travelRequestDTO.setRequestRaisedOn(new Date());
        travelRequestDTO.setFromDate(new Date(2025,1,15));
        travelRequestDTO.setToDate(new Date(2025,1,20));
        travelRequestDTO.setPurposeOfTravel("Business Meeting");
        travelRequestDTO.setRequestStatus("Approved");
        travelRequestDTO.setRequestApprovedOn(new Date(2025,1,10));
        travelRequestDTO.setPriority("Priority 1");
        travelRequestDTO.setLocationId(1);
        travelRequestDTO.setEmployeeName("Adrineel");

        TravelRequestDetailsDTO travelRequestDetailsDTO=new TravelRequestDetailsDTO();
        travelRequestDetailsDTO.setRequestId(1);
        travelRequestDetailsDTO.setRaisedByEmployeeId(101);
        travelRequestDetailsDTO.setToBeApprovedByHRId(201);
        travelRequestDetailsDTO.setRequestRaisedOn(new Date());
        travelRequestDetailsDTO.setFromDate(new Date(2025,1,15));
        travelRequestDetailsDTO.setToDate(new Date(2025,1,20));
        travelRequestDetailsDTO.setPurposeOfTravel("Business Meeting");
        travelRequestDetailsDTO.setLocationId(1);
        travelRequestDetailsDTO.setLocationName("Delhi");
        travelRequestDetailsDTO.setRequestStatus("Approved");
        travelRequestDetailsDTO.setRequestApprovedOn(new Date(2025,1,10));
        travelRequestDetailsDTO.setPriority("Priority 1");
        travelRequestDetailsDTO.setApprovedBudget(60000);
        travelRequestDetailsDTO.setApprovedModeOfTravel("Air");
        travelRequestDetailsDTO.setApprovedModeOfTravel("5-Star");
        travelRequestDetailsDTO.setEmployeeName("Adrineel");

        try {
            when(travelRequestService.addTravelRequest(Mockito.any())).thenReturn(travelRequestDetailsDTO);
            ResponseEntity<Integer> responseEntity=travelPlannerController.addTravelRequest(travelRequestDTO);
//            LoanAppDTO actualLoanAppDTO =responseEntity.getBody();
            assertEquals(201,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testAddTravelRequestWhenAddTravelRequestIsNotValid() {
        TravelRequestDTO travelRequestDTO =new TravelRequestDTO();
        travelRequestDTO.setRequestId(1);
        travelRequestDTO.setRaisedByEmployeeId(101);
        travelRequestDTO.setToBeApprovedByHRId(201);
        travelRequestDTO.setRequestRaisedOn(new Date(2023,12,10));
        travelRequestDTO.setFromDate(new Date(2025,1,15));
        travelRequestDTO.setToDate(new Date(2025,1,10));
        travelRequestDTO.setPurposeOfTravel("Business Meeting");
        travelRequestDTO.setRequestStatus("Approve");
        travelRequestDTO.setRequestApprovedOn(new Date(2025,1,10));
        travelRequestDTO.setPriority("Priority 4");
        travelRequestDTO.setLocationId(1);
        travelRequestDTO.setEmployeeName("Adrineel");

        validator.validate(travelRequestDTO).stream().forEach((constraintViolation)->assertNotNull(constraintViolation));
    }

    @Test
    public void testAddTravelRequestNegativeAssertReturnValue(){
        TravelRequestDTO travelRequestDTO =new TravelRequestDTO();
        travelRequestDTO.setRequestId(1);
        travelRequestDTO.setRaisedByEmployeeId(101);
        travelRequestDTO.setToBeApprovedByHRId(201);
        travelRequestDTO.setRequestRaisedOn(new Date(2023,12,10));
        travelRequestDTO.setFromDate(new Date(2025,1,15));
        travelRequestDTO.setToDate(new Date(2025,1,10));
        travelRequestDTO.setPurposeOfTravel("Business Meeting");
        travelRequestDTO.setRequestStatus("Approve");
        travelRequestDTO.setRequestApprovedOn(new Date(2025,1,10));
        travelRequestDTO.setPriority("Priority 4");
        travelRequestDTO.setLocationId(1);
        travelRequestDTO.setEmployeeName("Adrineel");

        TravelRequestDetailsDTO travelRequestDetailsDTO =null;

        try {
            when(travelRequestService.addTravelRequest(Mockito.any())).thenReturn(travelRequestDetailsDTO);
            ResponseEntity<Integer> responseEntity=travelPlannerController.addTravelRequest(travelRequestDTO);
//            LoanAppDTO actualLoanAppDTO =responseEntity.getBody();
            assertNull(responseEntity.getBody());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testAddTravelRequestNegativeAssertStatusCode(){
        TravelRequestDTO travelRequestDTO =new TravelRequestDTO();
        travelRequestDTO.setRequestId(1);
        travelRequestDTO.setRaisedByEmployeeId(101);
        travelRequestDTO.setToBeApprovedByHRId(201);
        travelRequestDTO.setRequestRaisedOn(new Date(2023,12,10));
        travelRequestDTO.setFromDate(new Date(2025,1,15));
        travelRequestDTO.setToDate(new Date(2025,1,10));
        travelRequestDTO.setPurposeOfTravel("Business Meeting");
        travelRequestDTO.setRequestStatus("Approve");
        travelRequestDTO.setRequestApprovedOn(new Date(2025,1,10));
        travelRequestDTO.setPriority("Priority 4");
        travelRequestDTO.setLocationId(1);
        travelRequestDTO.setEmployeeName("Adrineel");

        TravelRequestDetailsDTO travelRequestDetailsDTO =null;

        try {
            when(travelRequestService.addTravelRequest(Mockito.any())).thenReturn(travelRequestDetailsDTO);
            ResponseEntity<Integer> responseEntity=travelPlannerController.addTravelRequest(travelRequestDTO);
//            LoanAppDTO actualLoanAppDTO =responseEntity.getBody();
            assertEquals(400,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllPendingTravelRequestsPositiveAssertReturnValue() {
        List<TravelRequestDTO> travelRequestDTOList=new ArrayList<>();

        TravelRequestDTO travelRequestDTO =new TravelRequestDTO();
        travelRequestDTO.setRequestId(2);
        travelRequestDTO.setRaisedByEmployeeId(102);
        travelRequestDTO.setToBeApprovedByHRId(202);
        travelRequestDTO.setRequestRaisedOn(new Date());
        travelRequestDTO.setFromDate(new Date(2025,1,20));
        travelRequestDTO.setToDate(new Date(2025,1,25));
        travelRequestDTO.setPurposeOfTravel("Conference");
        travelRequestDTO.setRequestStatus("Approved");
        travelRequestDTO.setRequestApprovedOn(new Date(2025,1,15));
        travelRequestDTO.setPriority("Priority 2");
        travelRequestDTO.setLocationId(2);
        travelRequestDTO.setEmployeeName("Ankush");

        travelRequestDTOList.add(travelRequestDTO);

        try {
            when(travelRequestService.getAllPendingTravelRequests(Mockito.anyInt())).thenReturn(travelRequestDTOList);
            ResponseEntity<List<TravelRequestDTO>> responseEntity=travelPlannerController.getAllPendingTravelRequests(202);
            List<TravelRequestDTO> actualTravelRequestDTOList =responseEntity.getBody();
            assertTrue(actualTravelRequestDTOList.size()>0);
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllPendingTravelRequestsPositiveAssertStatusCode() {
        List<TravelRequestDTO> travelRequestDTOList=new ArrayList<>();

        TravelRequestDTO travelRequestDTO =new TravelRequestDTO();
        travelRequestDTO.setRequestId(2);
        travelRequestDTO.setRaisedByEmployeeId(102);
        travelRequestDTO.setToBeApprovedByHRId(202);
        travelRequestDTO.setRequestRaisedOn(new Date());
        travelRequestDTO.setFromDate(new Date(2025,1,20));
        travelRequestDTO.setToDate(new Date(2025,1,25));
        travelRequestDTO.setPurposeOfTravel("Conference");
        travelRequestDTO.setRequestStatus("Approved");
        travelRequestDTO.setRequestApprovedOn(new Date(2025,1,15));
        travelRequestDTO.setPriority("Priority 2");
        travelRequestDTO.setLocationId(2);
        travelRequestDTO.setEmployeeName("Ankush");

        travelRequestDTOList.add(travelRequestDTO);

        try {
            when(travelRequestService.getAllPendingTravelRequests(Mockito.anyInt())).thenReturn(travelRequestDTOList);
            ResponseEntity<List<TravelRequestDTO>> responseEntity=travelPlannerController.getAllPendingTravelRequests(202);
            assertEquals(200,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllPendingTravelRequestsNegativeAssertReturnValue() {
        List<TravelRequestDTO> travelRequestDTOList=new ArrayList<>();
        try {
            when(travelRequestService.getAllPendingTravelRequests(Mockito.anyInt())).thenReturn(travelRequestDTOList);
            ResponseEntity<List<TravelRequestDTO>> responseEntity=travelPlannerController.getAllPendingTravelRequests(202);
            assertNull(responseEntity.getBody());
        }catch(Exception e) {
//            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllPendingTravelRequestsNegativeAssertStatusCode() {
        List<TravelRequestDTO> travelRequestDTOList=new ArrayList<>();
        try {
            when(travelRequestService.getAllPendingTravelRequests(Mockito.anyInt())).thenReturn(travelRequestDTOList);
            ResponseEntity<List<TravelRequestDTO>> responseEntity=travelPlannerController.getAllPendingTravelRequests(202);
            assertEquals(400,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetApprovedTravelRequestDetailsPositiveAssertReturnValue() {
        TravelRequestDetailsDTO travelRequestDetailsDTO=new TravelRequestDetailsDTO();

        travelRequestDetailsDTO.setRequestId(4);
        travelRequestDetailsDTO.setRaisedByEmployeeId(104);
        travelRequestDetailsDTO.setToBeApprovedByHRId(204);
        travelRequestDetailsDTO.setRequestRaisedOn(new Date());
        travelRequestDetailsDTO.setFromDate(new Date(2025,2,1));
        travelRequestDetailsDTO.setToDate(new Date(2025,2,5));
        travelRequestDetailsDTO.setPurposeOfTravel("Project");
        travelRequestDetailsDTO.setRequestStatus("Approved");
        travelRequestDetailsDTO.setRequestApprovedOn(new Date(2025,1,25));
        travelRequestDetailsDTO.setPriority("Priority 3");
        travelRequestDetailsDTO.setLocationId(4);
        travelRequestDetailsDTO.setLocationName("Kolkata");
        travelRequestDetailsDTO.setApprovedBudget(75000);
        travelRequestDetailsDTO.setApprovedModeOfTravel("Air");
        travelRequestDetailsDTO.setApprovedHotelStarRating("5-Star");
        travelRequestDetailsDTO.setEmployeeName("Sayan");

        try {
            when(travelRequestService.getApprovedTravelRequestDetails(Mockito.anyInt())).thenReturn(travelRequestDetailsDTO);
            ResponseEntity<TravelRequestDetailsDTO> responseEntity=travelPlannerController.getApprovedTravelRequestDetails(4);
            TravelRequestDetailsDTO actualTravelRequestDetailsDTO =responseEntity.getBody();
            assertNotNull(actualTravelRequestDetailsDTO);
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetCustomerByIdPositiveAssertStatusCode() {
        TravelRequestDetailsDTO travelRequestDetailsDTO=new TravelRequestDetailsDTO();

        travelRequestDetailsDTO.setRequestId(4);
        travelRequestDetailsDTO.setRaisedByEmployeeId(104);
        travelRequestDetailsDTO.setToBeApprovedByHRId(204);
        travelRequestDetailsDTO.setRequestRaisedOn(new Date());
        travelRequestDetailsDTO.setFromDate(new Date(2025,2,1));
        travelRequestDetailsDTO.setToDate(new Date(2025,2,5));
        travelRequestDetailsDTO.setPurposeOfTravel("Project");
        travelRequestDetailsDTO.setRequestStatus("Approved");
        travelRequestDetailsDTO.setRequestApprovedOn(new Date(2025,1,25));
        travelRequestDetailsDTO.setPriority("Priority 3");
        travelRequestDetailsDTO.setLocationId(4);
        travelRequestDetailsDTO.setLocationName("Kolkata");
        travelRequestDetailsDTO.setApprovedBudget(75000);
        travelRequestDetailsDTO.setApprovedModeOfTravel("Air");
        travelRequestDetailsDTO.setApprovedHotelStarRating("5-Star");
        travelRequestDetailsDTO.setEmployeeName("Sayan");

        try {
            when(travelRequestService.getApprovedTravelRequestDetails(Mockito.anyInt())).thenReturn(travelRequestDetailsDTO);
            ResponseEntity<TravelRequestDetailsDTO> responseEntity=travelPlannerController.getApprovedTravelRequestDetails(4);
            assertEquals(200,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetCustomerByIdNegativeAssertReturnValue() {
        TravelRequestDetailsDTO travelRequestDetailsDTO=null;
        try {
            when(travelRequestService.getApprovedTravelRequestDetails(Mockito.anyInt())).thenReturn(travelRequestDetailsDTO);
            ResponseEntity<TravelRequestDetailsDTO> responseEntity=travelPlannerController.getApprovedTravelRequestDetails(4);
            TravelRequestDetailsDTO actualTravelRequestDetailsDTO =responseEntity.getBody();
            assertNull(actualTravelRequestDetailsDTO);
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetCustomerByIdNegativeAssertStatusCode() {
        TravelRequestDetailsDTO travelRequestDetailsDTO=null;
        try {
            when(travelRequestService.getApprovedTravelRequestDetails(Mockito.anyInt())).thenReturn(travelRequestDetailsDTO);
            ResponseEntity<TravelRequestDetailsDTO> responseEntity=travelPlannerController.getApprovedTravelRequestDetails(4);
            assertEquals(400,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testApproveOrRejectTravelRequestWhenAddUpdateTravelRequestIsValid() {
        UpdateTravelRequestDTO updateTravelRequestDTO=new UpdateTravelRequestDTO();

        updateTravelRequestDTO.setRequestId(6);
        updateTravelRequestDTO.setRequestStatus("Approved");
        updateTravelRequestDTO.setRequestApprovedOn(new Date(2025,12,20));
        updateTravelRequestDTO.setApprovedModeOfTravel("Air");
        updateTravelRequestDTO.setApprovedHotelStarRating("7-Star");

        validator.validate(updateTravelRequestDTO).stream().forEach((constraintViolation)->assertNull(constraintViolation));
    }

    @Test
    public void testApproveOrRejectTravelRequestPositiveAssertReturnValue(){
        UpdateTravelRequestDTO updateTravelRequestDTO=new UpdateTravelRequestDTO();

        updateTravelRequestDTO.setRequestId(6);
        updateTravelRequestDTO.setRequestStatus("Approved");
        updateTravelRequestDTO.setRequestApprovedOn(new Date(2025,12,20));
        updateTravelRequestDTO.setApprovedModeOfTravel("Air");
        updateTravelRequestDTO.setApprovedHotelStarRating("7-Star");

        TravelRequestDetailsDTO travelRequestDetailsDTO=new TravelRequestDetailsDTO();

        travelRequestDetailsDTO.setRequestId(6);
        travelRequestDetailsDTO.setRaisedByEmployeeId(106);
        travelRequestDetailsDTO.setToBeApprovedByHRId(206);
        travelRequestDetailsDTO.setRequestRaisedOn(new Date());
        travelRequestDetailsDTO.setFromDate(new Date(2025,1,15));
        travelRequestDetailsDTO.setToDate(new Date(2025,1,20));
        travelRequestDetailsDTO.setPurposeOfTravel("Workshop");
        travelRequestDetailsDTO.setRequestStatus("Approved");
        travelRequestDetailsDTO.setRequestApprovedOn(new Date(2025,12,20));
        travelRequestDetailsDTO.setPriority("Priority 1");
        travelRequestDetailsDTO.setLocationId(2);
        travelRequestDetailsDTO.setLocationName("Mumbai");
        travelRequestDetailsDTO.setApprovedBudget(90000);
        travelRequestDetailsDTO.setApprovedModeOfTravel("Air");
        travelRequestDetailsDTO.setApprovedHotelStarRating("7-Star");
        travelRequestDetailsDTO.setEmployeeName("Jigisha");

        try {
            when(travelRequestService.approveOrRejectTravelRequest(Mockito.anyInt(),Mockito.any())).thenReturn(travelRequestDetailsDTO);
            ResponseEntity<TravelRequestDetailsDTO> responseEntity=travelPlannerController.approveOrRejectTravelRequest(6,updateTravelRequestDTO);
            TravelRequestDetailsDTO actualTravelRequestDetailsDTO =responseEntity.getBody();
            assertNotNull(actualTravelRequestDetailsDTO);
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testApproveOrRejectTravelRequestPositiveAssertStatusCode(){
        UpdateTravelRequestDTO updateTravelRequestDTO=new UpdateTravelRequestDTO();

        updateTravelRequestDTO.setRequestId(6);
        updateTravelRequestDTO.setRequestStatus("Approved");
        updateTravelRequestDTO.setRequestApprovedOn(new Date(2025,12,20));
        updateTravelRequestDTO.setApprovedModeOfTravel("Air");
        updateTravelRequestDTO.setApprovedHotelStarRating("7-Star");

        TravelRequestDetailsDTO travelRequestDetailsDTO=new TravelRequestDetailsDTO();

        travelRequestDetailsDTO.setRequestId(6);
        travelRequestDetailsDTO.setRaisedByEmployeeId(106);
        travelRequestDetailsDTO.setToBeApprovedByHRId(206);
        travelRequestDetailsDTO.setRequestRaisedOn(new Date());
        travelRequestDetailsDTO.setFromDate(new Date(2025,1,15));
        travelRequestDetailsDTO.setToDate(new Date(2025,1,20));
        travelRequestDetailsDTO.setPurposeOfTravel("Workshop");
        travelRequestDetailsDTO.setRequestStatus("Approved");
        travelRequestDetailsDTO.setRequestApprovedOn(new Date(2025,12,20));
        travelRequestDetailsDTO.setPriority("Priority 1");
        travelRequestDetailsDTO.setLocationId(2);
        travelRequestDetailsDTO.setLocationName("Mumbai");
        travelRequestDetailsDTO.setApprovedBudget(90000);
        travelRequestDetailsDTO.setApprovedModeOfTravel("Air");
        travelRequestDetailsDTO.setApprovedHotelStarRating("7-Star");
        travelRequestDetailsDTO.setEmployeeName("Jigisha");

        try {
            when(travelRequestService.approveOrRejectTravelRequest(Mockito.anyInt(),Mockito.any())).thenReturn(travelRequestDetailsDTO);
            ResponseEntity<TravelRequestDetailsDTO> responseEntity=travelPlannerController.approveOrRejectTravelRequest(6,updateTravelRequestDTO);
            assertEquals(202,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testApproveOrRejectTravelRequestWhenAddUpdateTravelRequestIsNotValid() {
        UpdateTravelRequestDTO updateTravelRequestDTO=new UpdateTravelRequestDTO();

        updateTravelRequestDTO.setRequestId(6);
        updateTravelRequestDTO.setRequestStatus("ApprovedRejected");
        updateTravelRequestDTO.setRequestApprovedOn(new Date(2025,12,20));
        updateTravelRequestDTO.setApprovedModeOfTravel("TrainAir");
        updateTravelRequestDTO.setApprovedHotelStarRating("5-Star7-Star");

        validator.validate(updateTravelRequestDTO).stream().forEach((constraintViolation)->assertNotNull(constraintViolation));
    }

    @Test
    public void testApproveOrRejectTravelRequestNegativeAssertReturnValue(){
        UpdateTravelRequestDTO updateTravelRequestDTO=new UpdateTravelRequestDTO();

        updateTravelRequestDTO.setRequestId(6);
        updateTravelRequestDTO.setRequestStatus("ApprovedRejected");
        updateTravelRequestDTO.setRequestApprovedOn(new Date(2025,12,20));
        updateTravelRequestDTO.setApprovedModeOfTravel("TrainAir");
        updateTravelRequestDTO.setApprovedHotelStarRating("5-Star7-Star");

        TravelRequestDetailsDTO travelRequestDetailsDTO =null;

        try {
            when(travelRequestService.approveOrRejectTravelRequest(Mockito.anyInt(),Mockito.any())).thenReturn(travelRequestDetailsDTO);
            ResponseEntity<TravelRequestDetailsDTO> responseEntity=travelPlannerController.approveOrRejectTravelRequest(6,updateTravelRequestDTO);
            TravelRequestDetailsDTO actualTravelRequestDetailsDTO =responseEntity.getBody();
            assertNull(actualTravelRequestDetailsDTO);
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testApproveOrRejectTravelRequestNegativeAssertStatusCode(){
        UpdateTravelRequestDTO updateTravelRequestDTO=new UpdateTravelRequestDTO();

        updateTravelRequestDTO.setRequestId(6);
        updateTravelRequestDTO.setRequestStatus("ApprovedRejected");
        updateTravelRequestDTO.setRequestApprovedOn(new Date(2025,12,20));
        updateTravelRequestDTO.setApprovedModeOfTravel("TrainAir");
        updateTravelRequestDTO.setApprovedHotelStarRating("5-Star7-Star");

        TravelRequestDetailsDTO travelRequestDetailsDTO =null;

        try {
            when(travelRequestService.approveOrRejectTravelRequest(Mockito.anyInt(),Mockito.any())).thenReturn(travelRequestDetailsDTO);
            ResponseEntity<TravelRequestDetailsDTO> responseEntity=travelPlannerController.approveOrRejectTravelRequest(6,updateTravelRequestDTO);
            assertEquals(400,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testCalculateBudgetWhenAddTravelRequestIsValid() {
        TravelRequestDTO travelRequestDTO =new TravelRequestDTO();
        travelRequestDTO.setRequestId(1);
        travelRequestDTO.setRaisedByEmployeeId(101);
        travelRequestDTO.setToBeApprovedByHRId(201);
        travelRequestDTO.setRequestRaisedOn(new Date());
        travelRequestDTO.setFromDate(new Date(2025,1,15));
        travelRequestDTO.setToDate(new Date(2025,1,20));
        travelRequestDTO.setPurposeOfTravel("Business Meeting");
        travelRequestDTO.setRequestStatus("Approved");
        travelRequestDTO.setRequestApprovedOn(new Date(2025,1,10));
        travelRequestDTO.setPriority("Priority 1");
        travelRequestDTO.setLocationId(1);
        travelRequestDTO.setEmployeeName("Adrineel");

        validator.validate(travelRequestDTO).stream().forEach((constraintViolation)->assertNull(constraintViolation));
    }

    @Test
    public void testCalculateBudgetPositiveAssertReturnValue(){
        TravelRequestDTO travelRequestDTO =new TravelRequestDTO();
        travelRequestDTO.setRequestId(1);
        travelRequestDTO.setRaisedByEmployeeId(101);
        travelRequestDTO.setToBeApprovedByHRId(201);
        travelRequestDTO.setRequestRaisedOn(new Date());
        travelRequestDTO.setFromDate(new Date(2025,1,15));
        travelRequestDTO.setToDate(new Date(2025,1,20));
        travelRequestDTO.setPurposeOfTravel("Business Meeting");
        travelRequestDTO.setRequestStatus("Approved");
        travelRequestDTO.setRequestApprovedOn(new Date(2025,1,10));
        travelRequestDTO.setPriority("Priority 1");
        travelRequestDTO.setLocationId(1);
        travelRequestDTO.setEmployeeName("Adrineel");

        try {
            when(travelBudgetAllocationService.calculateBudget(Mockito.any())).thenReturn(60000);
            ResponseEntity<Integer> responseEntity=travelPlannerController.calculateBudget(travelRequestDTO);
            int actualBudget=responseEntity.getBody();
            assertNotNull(actualBudget);
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testCalculateBudgetPositiveAssertStatusCode(){
        TravelRequestDTO travelRequestDTO =new TravelRequestDTO();
        travelRequestDTO.setRequestId(1);
        travelRequestDTO.setRaisedByEmployeeId(101);
        travelRequestDTO.setToBeApprovedByHRId(201);
        travelRequestDTO.setRequestRaisedOn(new Date());
        travelRequestDTO.setFromDate(new Date(2025,1,15));
        travelRequestDTO.setToDate(new Date(2025,1,20));
        travelRequestDTO.setPurposeOfTravel("Business Meeting");
        travelRequestDTO.setRequestStatus("Approved");
        travelRequestDTO.setRequestApprovedOn(new Date(2025,1,10));
        travelRequestDTO.setPriority("Priority 1");
        travelRequestDTO.setLocationId(1);
        travelRequestDTO.setEmployeeName("Adrineel");

        try {
            when(travelBudgetAllocationService.calculateBudget(Mockito.any())).thenReturn(60000);
            ResponseEntity<Integer> responseEntity=travelPlannerController.calculateBudget(travelRequestDTO);
//            LoanAppDTO actualLoanAppDTO =responseEntity.getBody();
            assertEquals(201,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testCalculateBudgetWhenAddTravelRequestIsNotValid() {
        TravelRequestDTO travelRequestDTO =new TravelRequestDTO();
        travelRequestDTO.setRequestId(1);
        travelRequestDTO.setRaisedByEmployeeId(101);
        travelRequestDTO.setToBeApprovedByHRId(201);
        travelRequestDTO.setRequestRaisedOn(new Date(2023,12,10));
        travelRequestDTO.setFromDate(new Date(2025,1,15));
        travelRequestDTO.setToDate(new Date(2025,1,10));
        travelRequestDTO.setPurposeOfTravel("Business Meeting");
        travelRequestDTO.setRequestStatus("Approve");
        travelRequestDTO.setRequestApprovedOn(new Date(2025,1,10));
        travelRequestDTO.setPriority("Priority 4");
        travelRequestDTO.setLocationId(1);
        travelRequestDTO.setEmployeeName("Adrineel");

        validator.validate(travelRequestDTO).stream().forEach((constraintViolation)->assertNotNull(constraintViolation));
    }

    @Test
    public void testCalculateBudgetNegativeAssertReturnValue(){
        TravelRequestDTO travelRequestDTO =null;

        try {
            when(travelBudgetAllocationService.calculateBudget(Mockito.any())).thenReturn(0);
            ResponseEntity<Integer> responseEntity=travelPlannerController.calculateBudget(travelRequestDTO);
//            int actualBudget=responseEntity.getBody();
            assertNull(responseEntity.getBody());
        }catch(Exception e) {
//            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testCalculateBudgetNegativeAssertStatusCode(){
        TravelRequestDTO travelRequestDTO =null;

        try {
            when(travelBudgetAllocationService.calculateBudget(Mockito.any())).thenReturn(0);
            ResponseEntity<Integer> responseEntity=travelPlannerController.calculateBudget(travelRequestDTO);
//            LoanAppDTO actualLoanAppDTO =responseEntity.getBody();
            assertEquals(400,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

}
