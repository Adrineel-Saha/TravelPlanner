INSERT INTO Locations (Id, Name) VALUES
(1, 'Delhi'),
(2, 'Mumbai'),
(3, 'Hyderabad'),
(4, 'Kolkata'),
(5, 'Bangalore');

INSERT INTO Travel_Requests (Request_Id, Raised_By_Employee_Id, To_Be_Approved_By_HR_Id, Request_Raised_On, From_Date, To_Date, Purpose_Of_Travel, Request_Status, Request_Approved_On, Priority, Location_Id) VALUES
(1, 101, 201, CURRENT_DATE, '2025-01-15', '2025-01-20', 'Business Meeting', 'Approved', '2025-01-10', 'Priority 1', 1),
(2, 102, 202, CURRENT_DATE, '2025-01-20', '2025-01-25', 'Conference', 'Approved', '2025-01-15', 'Priority 2', 2),
(3, 103, 203, CURRENT_DATE, '2025-01-25', '2025-01-30', 'Training', 'Rejected', NULL, 'Priority 3', 3),
(4, 104, 204, CURRENT_DATE, '2025-02-01', '2025-02-05', 'Project', 'Approved', '2025-01-25', 'Priority 1', 4),
(5, 105, 205, CURRENT_DATE, '2025-02-10', '2025-02-15', 'Site Visit', 'Approved', '2025-02-05', 'Priority 2', 5),
(6, 106, 206, CURRENT_DATE, '2025-01-15', '2025-01-20', 'Workshop', 'New', NULL, 'Priority 1', 2),
(7, 107, 207, CURRENT_DATE, '2025-01-20', '2025-01-25', 'Seminar', 'New', NULL, 'Priority 2', 3);

INSERT INTO Travel_Budget_Allocations (Approved_Budget, Approved_Mode_Of_Travel, Approved_Hotel_Star_Rating, Travel_Request_Id) VALUES
(60000, 'Air', '5-Star', 1),  -- Grade 1: 6 days * 10000 INR/day = 60000
(75000, 'Train', '5-Star', 2), -- Grade 2: 6 days * 12500 INR/day = 75000
(0, NULL, NULL, 3),  -- Rejected request, no approval details needed
(50000, 'Air', '7-Star', 4),  -- Grade 1: 5 days * 10000 INR/day = 75000
(75000, 'Train', '5-Star', 5),  -- Grade 2: 6 days * 12500 INR/day = 75000
(0, NULL, NULL, 6),  -- New request, awaiting approval
(0, NULL, NULL, 7);  -- New request, awaiting approval


INSERT INTO Employees (Employee_Id, Employee_Name, Password, Role, Current_Grade, Is_Account_Locked) VALUES
(101, 'Adrineel', 'Adri@2001', 'Employee', 'Grade 1', false),
(102, 'Ankush', 'Ankush#1810', 'Employee', 'Grade 2', false),
(103, 'Yash', 'Yash&2909', 'HR', 'Grade 3', false),
(104, 'Sayan', 'Sayan_1999', 'Employee', 'Grade 1', false),
(105, 'Sirsha', '3110@Sirsha', 'TravelDeskExec', 'Grade 2', false),
(106, 'Jigisha', '3004_Jigisha', 'HR', 'Grade 3', false),
(107, 'Debasmita', '2510#Debasmita', 'TravelDeskExec', 'Grade 1', false),
(201, 'Ashish', 'Ashish#1803', 'HR', 'Grade 2', false),
(202, 'Rakesh', '1303_Rakesh', 'HR', 'Grade 3', false),
(203, 'Shubham', '2000&Shubham', 'HR', 'Grade 1', false),
(204, 'Arunabh', 'Arunabh@1102', 'HR', 'Grade 2', false),
(205, 'Ayan', 'Ayan#1704', 'HR', 'Grade 3', false),
(206, 'Kamlesh', '1999@Kamlesh', 'HR', 'Grade 1', false),
(207, 'Amaey', 'Amaey&2000', 'HR', 'Grade 2', false);


