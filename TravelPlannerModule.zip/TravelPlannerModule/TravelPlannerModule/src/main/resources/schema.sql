CREATE TABLE Locations (
    Id INT,
    Name VARCHAR(255) NOT NULL,
    CONSTRAINT PK1 PRIMARY KEY (Id)
);

CREATE TABLE Travel_Requests (
    Request_Id INT,
    Raised_By_Employee_Id INT NOT NULL,
    To_Be_Approved_By_HR_Id INT NOT NULL,
    Request_Raised_On DATE DEFAULT (CURDATE()),
    From_Date DATE NOT NULL,
    To_Date DATE NOT NULL,
    Purpose_Of_Travel VARCHAR(255),
    Request_Status VARCHAR(50) NOT NULL CHECK(Request_Status IN ('New', 'Approved', 'Rejected')),
    Request_Approved_On DATE,
    Priority VARCHAR(50) NOT NULL CHECK(Priority IN ('Priority 1', 'Priority 2', 'Priority 3')),
    Location_Id INT,
    CONSTRAINT CK1 CHECK (To_Date >= From_Date),
    CONSTRAINT PK2 PRIMARY KEY (Request_Id),
    CONSTRAINT FK2 FOREIGN KEY (Location_Id) REFERENCES Locations(Id)
);

CREATE TABLE Travel_Budget_Allocations (
    Id INT AUTO_INCREMENT,
    Approved_Budget INT NOT NULL DEFAULT 0,
    Approved_Mode_Of_Travel  VARCHAR(20) CHECK(Approved_Mode_Of_Travel IN('Air', 'Train', 'Bus')),
    Approved_Hotel_Star_Rating VARCHAR(50) CHECK(Approved_Hotel_Star_Rating IN ('3-Star', '5-Star', '7-Star')),
    Travel_Request_Id INT,
    CONSTRAINT PK3 PRIMARY KEY (Id),
    CONSTRAINT FK3 FOREIGN KEY (Travel_Request_Id) REFERENCES Travel_Requests(Request_Id)
);

CREATE TABLE Employees (
    Employee_Id INT,
    Employee_Name VARCHAR(40) UNIQUE NOT NULL,
    Password VARCHAR(40) NOT NULL,
    Role VARCHAR(15) NOT NULL CHECK (Role IN ('Employee', 'HR', 'TravelDeskExec')),
    Current_Grade VARCHAR(10) NOT NULL CHECK (Current_Grade IN ('Grade 1', 'Grade 2', 'Grade 3')),
    Is_Account_Locked BOOLEAN DEFAULT FALSE,
    CONSTRAINT PK4 PRIMARY KEY(Employee_Id)
);

