package com.cognizant.employeetraveldesk.travelplanner.repositories;

import com.cognizant.employeetraveldesk.travelplanner.entities.TravelRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TravelRequestRepository extends JpaRepository<TravelRequest,Integer> {
    List<TravelRequest> findByToBeApprovedByHRId(int HRid);
}
