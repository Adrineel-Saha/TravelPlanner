package com.cognizant.employeetraveldesk.travelplanner.services;

import com.cognizant.employeetraveldesk.travelplanner.dtos.TravelRequestDTO;
import com.cognizant.employeetraveldesk.travelplanner.dtos.TravelRequestDetailsDTO;
import com.cognizant.employeetraveldesk.travelplanner.dtos.UpdateTravelRequestDTO;

import java.util.List;

public interface TravelRequestService {
    public TravelRequestDetailsDTO addTravelRequest(TravelRequestDTO travelRequestDTO);
    public List<TravelRequestDTO> getAllPendingTravelRequests(int HRid);
    public TravelRequestDetailsDTO getApprovedTravelRequestDetails(int trid);
    public TravelRequestDetailsDTO approveOrRejectTravelRequest(int trid, UpdateTravelRequestDTO updateTravelRequestDTO);
}
