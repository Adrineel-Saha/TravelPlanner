package com.cognizant.employeetraveldesk.travelplanner.controllers;

import com.cognizant.employeetraveldesk.travelplanner.dtos.EmployeeDTO;
import com.cognizant.employeetraveldesk.travelplanner.dtos.EmployeeRequestDTO;
import com.cognizant.employeetraveldesk.travelplanner.services.EmployeeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("authenticate")
@CrossOrigin(origins = "http://localhost:4200")
@Tag(name="Authentication", description = "Authentication REST API")
public class AuthenticationController {
    @Autowired
    private EmployeeService employeeService;

    @PostMapping("employees")
    @Operation(summary="Check Authenticated Employee", description="Checks whether an employee is authenticated")
    public ResponseEntity<EmployeeDTO> authenticate(@RequestBody EmployeeRequestDTO employeeRequestDTO) {
        log.info("Authenticating an employee: " + employeeRequestDTO);

        EmployeeDTO employeeDTO = employeeService.authenticateEmployee(employeeRequestDTO.getEmployeeName(), employeeRequestDTO.getPassword());
        if (employeeDTO.getEmployeeName() != null) {
            return new ResponseEntity<>(employeeDTO, HttpStatus.ACCEPTED);
        } else {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }
    }
}

