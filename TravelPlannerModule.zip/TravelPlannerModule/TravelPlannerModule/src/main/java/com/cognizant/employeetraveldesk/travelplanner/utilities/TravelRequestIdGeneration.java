package com.cognizant.employeetraveldesk.travelplanner.utilities;

import java.util.Random;

public class TravelRequestIdGeneration {
    public static int generateTravelRequestId() {
        int randomNumber=new Random().nextInt(9000)+1000;
        return randomNumber;
    }
}
