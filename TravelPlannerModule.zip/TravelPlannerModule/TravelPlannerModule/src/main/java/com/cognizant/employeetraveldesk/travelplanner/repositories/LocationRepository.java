package com.cognizant.employeetraveldesk.travelplanner.repositories;

import com.cognizant.employeetraveldesk.travelplanner.entities.Location;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LocationRepository extends JpaRepository<Location,Integer> {
}
