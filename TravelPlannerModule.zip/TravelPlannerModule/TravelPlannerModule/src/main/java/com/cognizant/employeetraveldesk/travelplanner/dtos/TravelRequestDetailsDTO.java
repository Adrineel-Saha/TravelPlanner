package com.cognizant.employeetraveldesk.travelplanner.dtos;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.time.DateUtils;

import java.util.Calendar;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TravelRequestDetailsDTO {
    private int requestId;

    @NotNull
    private int raisedByEmployeeId;

    private String employeeName;

    @NotNull
    private int toBeApprovedByHRId;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date requestRaisedOn;

    @NotNull
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date fromDate;

    @NotNull
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date toDate;

    private String purposeOfTravel;

    private int locationId;

    private String locationName;  // Adding Location name for better clarity

    @NotNull
    @Pattern(regexp = "^(New|Approved|Rejected)$")
    private String requestStatus;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date requestApprovedOn;

    @NotNull
    @Pattern(regexp = "^(Priority 1|Priority 2|Priority 3)$")
    private String priority;

    private int approvedBudget;

    @Pattern(regexp = "^(Air|Train|Bus)$")
    private String approvedModeOfTravel;

    @Pattern(regexp = "^(3-Star|5-Star|7-Star)$")
    private String approvedHotelStarRating;

    @JsonIgnore
    @AssertTrue(message="Request_Raised_On should be CURRENTDATE")
    public boolean isRequestRaisedOnEqualsCurrentDate() {
        return DateUtils.truncate(requestRaisedOn, Calendar.DAY_OF_MONTH).equals(DateUtils.truncate(new Date(), Calendar.DAY_OF_MONTH));
    }

    @JsonIgnore
    @AssertTrue(message="From_Date must not be lesser than Request_Raised_On")
    public boolean isFromDateNotBeforeRequestRaisedOn() {
        return requestRaisedOn.before(fromDate);
    }

//    @JsonIgnore
//    @AssertTrue(message="From_Date must not be lesser than Request_Approved_On")
//    public boolean isFromDateNotBeforeRequestApprovedOn() {
//        return requestApprovedOn.before(fromDate);
//    }

//    @JsonIgnore
//    @AssertTrue(message="Request_Approved_On must not be lesser than Request_Raised_On")
//    public boolean isRequestApprovedOnNotBeforeFromDate() {
//        return requestRaisedOn.before(requestApprovedOn);
//    }

    @JsonIgnore
    @AssertTrue(message="To_Date must not be lesser than From_Date")
    public boolean isToDateNotBeforeFromDate() {
        return fromDate.before(toDate);
    }
}

