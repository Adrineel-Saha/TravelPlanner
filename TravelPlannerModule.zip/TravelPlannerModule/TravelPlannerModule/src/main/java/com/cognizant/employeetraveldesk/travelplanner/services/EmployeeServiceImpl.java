package com.cognizant.employeetraveldesk.travelplanner.services;

import com.cognizant.employeetraveldesk.travelplanner.dtos.EmployeeDTO;
import com.cognizant.employeetraveldesk.travelplanner.entities.Employee;
import com.cognizant.employeetraveldesk.travelplanner.repositories.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeServiceImpl implements EmployeeService{
    @Autowired
    private EmployeeRepository employeeRepository;

    @Override
    public String getEmployeeGrade(int employeeId) {
        Optional<Employee> employeeOptional=employeeRepository.findById(employeeId);
        Employee employee=employeeOptional.orElseThrow(()->new RuntimeException("Employee not found with id: "+employeeId));
        return employee.getCurrentGrade();
    }

    @Override
    public String getEmployeeRole(int employeeId) {
        Optional<Employee> employeeOptional=employeeRepository.findById(employeeId);
        Employee employee=employeeOptional.orElseThrow(()->new RuntimeException("Employee not found with id: "+employeeId));
        return employee.getRole();
    }

    @Override
    public String getEmployeeName(int employeeId) {
        Optional<Employee> employeeOptional=employeeRepository.findById(employeeId);
        Employee employee=employeeOptional.orElseThrow(()->new RuntimeException("Employee not found with id: "+employeeId));
        return employee.getEmployeeName();
    }

    @Override
    public List<Employee> listOfEmployees() {
        return employeeRepository.findAll();
    }

    @Override
    public EmployeeDTO authenticateEmployee(String employeeName, String password) {
        List<Employee> employees = listOfEmployees();
        EmployeeDTO employeeDTO = new EmployeeDTO();
        for (Employee employee : employees) {
            if (employee.getEmployeeName().equals(employeeName) && employee.getPassword().equals(password) && !employee.isAccountLocked()) {
                employeeDTO.setEmployeeId(employee.getEmployeeId());
                employeeDTO.setEmployeeName(employee.getEmployeeName());
                employeeDTO.setPassword(employee.getPassword());
                employeeDTO.setRole(employee.getRole());
                employeeDTO.setCurrentGrade(employee.getCurrentGrade());
                employeeDTO.setAccountLocked(employee.isAccountLocked());
                break;
            }
        }
        return employeeDTO;
    }
}
