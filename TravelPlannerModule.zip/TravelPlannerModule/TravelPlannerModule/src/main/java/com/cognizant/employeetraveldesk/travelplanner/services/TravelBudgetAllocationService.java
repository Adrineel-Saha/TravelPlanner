package com.cognizant.employeetraveldesk.travelplanner.services;

import com.cognizant.employeetraveldesk.travelplanner.dtos.TravelRequestDTO;

public interface TravelBudgetAllocationService {
    public int calculateBudget(TravelRequestDTO travelRequestDTO);
}
