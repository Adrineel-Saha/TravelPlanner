package com.cognizant.employeetraveldesk.travelplanner.services;

import com.cognizant.employeetraveldesk.travelplanner.dtos.LocationDTO;
import com.cognizant.employeetraveldesk.travelplanner.entities.Location;
import com.cognizant.employeetraveldesk.travelplanner.repositories.LocationRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Service
public class LocationServiceImpl implements LocationService{
    @Autowired
    private LocationRepository locationRepository;
    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<LocationDTO> getAllLocations() {
        List<Location> locationList=locationRepository.findAll();
        List<LocationDTO> locationDTOList =new ArrayList<>();
        Iterator<Location> locationIterator =locationList.iterator();

        while(locationIterator.hasNext()) {
            Location location= locationIterator.next();
            LocationDTO locationDTO =modelMapper.map(location, LocationDTO.class);
            locationDTOList.add(locationDTO);
        }

        if(locationDTOList.isEmpty()) {
            throw new RuntimeException("List is empty");
        }
        return locationDTOList;
    }
}
