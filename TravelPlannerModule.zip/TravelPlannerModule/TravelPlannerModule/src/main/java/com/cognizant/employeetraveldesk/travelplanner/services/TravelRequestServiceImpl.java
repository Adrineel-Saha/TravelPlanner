package com.cognizant.employeetraveldesk.travelplanner.services;

import com.cognizant.employeetraveldesk.travelplanner.dtos.TravelRequestDTO;
import com.cognizant.employeetraveldesk.travelplanner.dtos.TravelRequestDetailsDTO;
import com.cognizant.employeetraveldesk.travelplanner.dtos.UpdateTravelRequestDTO;
import com.cognizant.employeetraveldesk.travelplanner.entities.Location;
import com.cognizant.employeetraveldesk.travelplanner.entities.TravelBudgetAllocation;
import com.cognizant.employeetraveldesk.travelplanner.entities.TravelRequest;
import com.cognizant.employeetraveldesk.travelplanner.repositories.LocationRepository;
import com.cognizant.employeetraveldesk.travelplanner.repositories.TravelBudgetAllocationRepository;
import com.cognizant.employeetraveldesk.travelplanner.repositories.TravelRequestRepository;
import com.cognizant.employeetraveldesk.travelplanner.utilities.TravelRequestIdGeneration;
import com.cognizant.employeetraveldesk.travelplanner.utilities.TravelRequestValidation;
import com.cognizant.employeetraveldesk.travelplanner.utilities.UpdateTravelRequestValidation;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class TravelRequestServiceImpl implements  TravelRequestService{
    @Autowired
    TravelRequestRepository travelRequestRepository;
    @Autowired
    LocationRepository locationRepository;
    @Autowired
    TravelBudgetAllocationRepository travelBudgetAllocationRepository;
    @Autowired
    EmployeeService employeeService;
    @Autowired
    ModelMapper modelMapper;

    @Override
    public TravelRequestDetailsDTO addTravelRequest(TravelRequestDTO travelRequestDTO) {
        TravelRequestValidation travelRequestValidation=new TravelRequestValidation();
        travelRequestValidation.validateTravelRequest(travelRequestDTO);
        travelRequestDTO.setRequestId(TravelRequestIdGeneration.generateTravelRequestId());

        int allowedDays = getAllowedDays(travelRequestDTO.getPriority());
        int actualDays = (int) ((travelRequestDTO.getToDate().getTime() - travelRequestDTO.getFromDate().getTime()) / (1000 * 60 * 60 * 24)) + 1;
        if (actualDays > allowedDays) {
            throw new IllegalArgumentException("Exceeded maximum allowed on-site days for " + travelRequestDTO.getPriority());
        }

        Optional<Location> locationOptional=locationRepository.findById(travelRequestDTO.getLocationId());
        Location location=locationOptional.orElseThrow(()->new RuntimeException("Location not found with id: "+travelRequestDTO.getLocationId()));

        TravelRequest travelRequest=modelMapper.map(travelRequestDTO,TravelRequest.class);
        travelRequest.setLocation(location);

        TravelRequest newTravelRequest=travelRequestRepository.save(travelRequest);

        TravelBudgetAllocation travelBudgetAllocation=new TravelBudgetAllocation();
        travelBudgetAllocation.setApprovedBudget(0);
        travelBudgetAllocation.setApprovedModeOfTravel(null);
        travelBudgetAllocation.setApprovedHotelStarRating(null);
        travelBudgetAllocation.setTravelRequest(newTravelRequest);

        TravelBudgetAllocation newtravelBudgetAllocation=travelBudgetAllocationRepository.save(travelBudgetAllocation);

//        TravelRequestDTO newTravelRequestDTO=modelMapper.map(newTravelRequest,TravelRequestDTO.class);
//        newTravelRequestDTO.setLocationId(newTravelRequest.getLocation().getId());

        TravelRequestDetailsDTO newTravelRequestDetailsDTO=modelMapper.map(newTravelRequest,TravelRequestDetailsDTO.class);
        modelMapper.map(newTravelRequest.getLocation(),newTravelRequestDetailsDTO);
        modelMapper.map(newtravelBudgetAllocation,newTravelRequestDetailsDTO);

//        return newTravelRequestDTO;

        return newTravelRequestDetailsDTO;
    }

    @Override
    public List<TravelRequestDTO> getAllPendingTravelRequests(int HRid) {
        List<TravelRequest> travelRequestList=travelRequestRepository.findByToBeApprovedByHRId(HRid);
        List<TravelRequestDTO> travelRequestDTOList=new ArrayList<>();
        Iterator<TravelRequest> travelRequestIterator =travelRequestList.iterator();

        while(travelRequestIterator.hasNext()) {
            TravelRequest travelRequest= travelRequestIterator.next();
            if(travelRequest.getRequestStatus().equals("New")) {
                TravelRequestDTO travelRequestDTO = modelMapper.map(travelRequest, TravelRequestDTO.class);
                travelRequestDTO.setLocationId(travelRequest.getLocation().getId());
                travelRequestDTO.setEmployeeName(employeeService.getEmployeeName(travelRequest.getRaisedByEmployeeId()));
                travelRequestDTOList.add(travelRequestDTO);
            }
        }

        if(travelRequestDTOList.isEmpty()) {
            throw new RuntimeException("List is empty");
        }
        return travelRequestDTOList;
    }

    @Override
    public TravelRequestDetailsDTO getApprovedTravelRequestDetails(int trid) {
        Optional<TravelRequest> travelRequestOptional=travelRequestRepository.findById(trid);
        TravelRequest  travelRequest=travelRequestOptional.orElseThrow(()->new RuntimeException("Travel Request not found with id: "+ trid));

//        Optional<TravelBudgetAllocation> travelBudgetAllocationOptional=travelBudgetAllocationRepository.findByTravelRequestRequestId(trid);
//        TravelBudgetAllocation travelBudgetAllocation=travelBudgetAllocationOptional.orElseThrow(()->new RuntimeException("Travel Budget Allocation not found with Travel Request Id: "+ trid));

        if(travelRequest.getRequestStatus().equals("Approved")){
            Optional<TravelBudgetAllocation> travelBudgetAllocationOptional=travelBudgetAllocationRepository.findByTravelRequestRequestId(trid);
            TravelBudgetAllocation travelBudgetAllocation=travelBudgetAllocationOptional.orElseThrow(()->new RuntimeException("Travel Budget Allocation not found with Travel Request Id: "+ trid));

            TravelRequestDetailsDTO travelRequestDetailsDTO=modelMapper.map(travelRequest,TravelRequestDetailsDTO.class);
            modelMapper.map(travelRequest.getLocation(),travelRequestDetailsDTO);
            modelMapper.map(travelBudgetAllocation,travelRequestDetailsDTO);
            travelRequestDetailsDTO.setEmployeeName(employeeService.getEmployeeName(travelRequest.getRaisedByEmployeeId()));

            return travelRequestDetailsDTO;
        }
        else{
//            throw new RuntimeException("Travel Request is not Approved");
            TravelRequestDetailsDTO travelRequestDetailsDTO=modelMapper.map(travelRequest,TravelRequestDetailsDTO.class);
            modelMapper.map(travelRequest.getLocation(),travelRequestDetailsDTO);
            travelRequestDetailsDTO.setEmployeeName(employeeService.getEmployeeName(travelRequest.getRaisedByEmployeeId()));

            return travelRequestDetailsDTO;
        }
//        return travelRequestDetailsDTO;
    }

    @Override
    public TravelRequestDetailsDTO approveOrRejectTravelRequest(int trid, UpdateTravelRequestDTO updateTravelRequestDTO) {
        UpdateTravelRequestValidation updateTravelRequestValidation=new UpdateTravelRequestValidation();
        updateTravelRequestValidation.validateUpdateTravelRequest(updateTravelRequestDTO);

        Optional<TravelRequest> travelRequestOptional=travelRequestRepository.findById(trid);
        TravelRequest travelRequest=travelRequestOptional.orElseThrow(()->new RuntimeException("Travel Request not found with id: "+trid));

//        Optional<TravelBudgetAllocation> travelBudgetAllocationOptional=travelBudgetAllocationRepository.findByTravelRequestRequestId(trid);
//        TravelBudgetAllocation travelBudgetAllocation=travelBudgetAllocationOptional.orElseThrow(()->new RuntimeException("Travel Budget Allocation not found with Travel Request Id: "+trid));
//        TravelBudgetAllocation updatedTravelBudgetAllocation=null;

//        travelRequest.setRequestStatus(updateTravelRequestDTO.getRequestStatus());
//        travelRequest.setRequestApprovedOn(updateTravelRequestDTO.getRequestApprovedOn() != null ? updateTravelRequestDTO.getRequestApprovedOn() : new Date());
//        TravelRequest updatedTravelRequest=travelRequestRepository.save(travelRequest);

//        int actualDays = (int) ((travelRequest.getToDate().getTime() - travelRequest.getFromDate().getTime()) / (1000 * 60 * 60 * 24)) + 1;

        if(updateTravelRequestDTO.getRequestStatus().equals("Approved") && travelRequest.getRequestStatus().equals("New")){
            Optional<TravelBudgetAllocation> travelBudgetAllocationOptional=travelBudgetAllocationRepository.findByTravelRequestRequestId(trid);
            TravelBudgetAllocation travelBudgetAllocation=travelBudgetAllocationOptional.orElseThrow(()->new RuntimeException("Travel Budget Allocation not found with Travel Request Id: "+trid));

//            travelRequest.setRequestStatus(updateTravelRequestDTO.getRequestStatus());
//            travelRequest.setRequestApprovedOn(updateTravelRequestDTO.getRequestApprovedOn() != null ? updateTravelRequestDTO.getRequestApprovedOn() : new Date());
//            TravelRequest updatedTravelRequest=travelRequestRepository.save(travelRequest);

            String grade = employeeService.getEmployeeGrade(travelRequest.getRaisedByEmployeeId());
            int actualDays = (int) ((travelRequest.getToDate().getTime() - travelRequest.getFromDate().getTime()) / (1000 * 60 * 60 * 24)) + 1;

            int allowedBudget = calculateAllowedBudget(grade, actualDays);
//            if (dto.getApprovedBudget() > allowedBudget) { throw new IllegalArgumentException("Approved budget exceeds the allowed limit for employee grade"); }

            boolean isHR = employeeService.getEmployeeRole(travelRequest.getRaisedByEmployeeId()).equals("HR");

            if (!isValidHotelStarRating(updateTravelRequestDTO.getApprovedHotelStarRating(), isHR))
            {
                throw new IllegalArgumentException("Invalid hotel star rating for employee role");
            }

            travelRequest.setRequestStatus(updateTravelRequestDTO.getRequestStatus());
            travelRequest.setRequestApprovedOn(updateTravelRequestDTO.getRequestApprovedOn() != null ? updateTravelRequestDTO.getRequestApprovedOn() : new Date());
            TravelRequest updatedTravelRequest=travelRequestRepository.save(travelRequest);

//            Optional<TravelBudgetAllocation> travelBudgetAllocationOptional=travelBudgetAllocationRepository.findByTravelRequestRequestId(trid);
//            TravelBudgetAllocation travelBudgetAllocation=travelBudgetAllocationOptional.orElseThrow(()->new RuntimeException("Travel Budget Allocation not found with Travel Request Id: "+trid));

//            if (travelBudgetAllocation.getApprovedBudget() == 0) {
//                travelBudgetAllocation.setApprovedBudget(0);
//            }

//            log.info("Fetched TravelBudgetAllocation: {}", travelBudgetAllocation); // Log and set approvedBudget
//            log.info("Setting approved budget to: {}", allowedBudget);

            travelBudgetAllocation.setApprovedBudget(allowedBudget);
            travelBudgetAllocation.setApprovedModeOfTravel(updateTravelRequestDTO.getApprovedModeOfTravel());
            travelBudgetAllocation.setApprovedHotelStarRating(updateTravelRequestDTO.getApprovedHotelStarRating());
            TravelBudgetAllocation updatedTravelBudgetAllocation=travelBudgetAllocationRepository.save(travelBudgetAllocation);
//            log.info("Saved TravelBudgetAllocation with approvedBudget: {}", updatedTravelBudgetAllocation.getApprovedBudget());

            TravelRequestDetailsDTO travelRequestDetailsDTO=modelMapper.map(updatedTravelRequest,TravelRequestDetailsDTO.class);
            modelMapper.map(updatedTravelRequest.getLocation(),travelRequestDetailsDTO);
            modelMapper.map(updatedTravelBudgetAllocation,travelRequestDetailsDTO);
            travelRequestDetailsDTO.setEmployeeName(employeeService.getEmployeeName(updatedTravelRequest.getRaisedByEmployeeId()));

            return travelRequestDetailsDTO;
        }
        else if(updateTravelRequestDTO.getRequestStatus().equals("Rejected") && travelRequest.getRequestStatus().equals("New")){
            Optional<TravelBudgetAllocation> travelBudgetAllocationOptional=travelBudgetAllocationRepository.findByTravelRequestRequestId(trid);
            TravelBudgetAllocation travelBudgetAllocation=travelBudgetAllocationOptional.orElseThrow(()->new RuntimeException("Travel Budget Allocation not found with Travel Request Id: "+trid));

            travelRequest.setRequestStatus(updateTravelRequestDTO.getRequestStatus());
            TravelRequest updatedTravelRequest=travelRequestRepository.save(travelRequest);

//            Optional<TravelBudgetAllocation> travelBudgetAllocationOptional=travelBudgetAllocationRepository.findByTravelRequestRequestId(trid);
//            TravelBudgetAllocation travelBudgetAllocation=travelBudgetAllocationOptional.orElseThrow(()->new RuntimeException("Travel Budget Allocation not found with Travel Request Id: "+trid));

            TravelRequestDetailsDTO travelRequestDetailsDTO=modelMapper.map(updatedTravelRequest,TravelRequestDetailsDTO.class);
            modelMapper.map(updatedTravelRequest.getLocation(),travelRequestDetailsDTO);
            modelMapper.map(travelBudgetAllocation,travelRequestDetailsDTO);
            travelRequestDetailsDTO.setEmployeeName(employeeService.getEmployeeName(updatedTravelRequest.getRaisedByEmployeeId()));

            return travelRequestDetailsDTO;
        }
        else{
            throw new RuntimeException("Cannot update an Approved/Rejected Travel Request");
        }
//        TravelRequestDetailsDTO travelRequestDetailsDTO=modelMapper.map(travelRequest,TravelRequestDetailsDTO.class);
//        modelMapper.map(travelRequest.getLocation(),travelRequestDetailsDTO);
//        modelMapper.map(travelBudgetAllocation,travelRequestDetailsDTO);

//        return travelRequestDetailsDTO;
    }

    private int getAllowedDays(String priority) {
        switch (priority) {
            case "Priority 1":
                return 30;
            case "Priority 2":
                return 20;
            case "Priority 3":
                return 10;
            default:
                throw new IllegalArgumentException("Invalid priority: " + priority);
        }
    }

    private int calculateAllowedBudget(String grade, int days) {
        switch (grade) {
            case "Grade 1":
                return days * 10000;
            case "Grade 2":
                return days * 12500;
            case "Grade 3":
                return days * 15000;
            default:
                throw new IllegalArgumentException("Invalid employee grade: " + grade);
        }
    }

    private boolean isValidHotelStarRating(String hotelStarRating, boolean isHR) {
        if (isHR) {
            return hotelStarRating.equals("5-Star") || hotelStarRating.equals("7-Star");
        }
        else {
            return hotelStarRating.equals("3-Star") || hotelStarRating.equals("5-Star");
        }
    }
}
