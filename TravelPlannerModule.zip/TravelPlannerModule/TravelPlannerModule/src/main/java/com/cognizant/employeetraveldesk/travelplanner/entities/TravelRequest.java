package com.cognizant.employeetraveldesk.travelplanner.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Entity
@Table(name="Travel_Requests")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TravelRequest {
    @Id
    @Column(name="Request_Id")
    private int requestId;

    @Column(name="Raised_By_Employee_Id")
    private int raisedByEmployeeId;

    @Column(name="To_Be_Approved_By_HR_Id")
    private int toBeApprovedByHRId;

    @Column(name="Request_Raised_On")
    @Temporal(TemporalType.DATE)
    private Date requestRaisedOn;

    @Column(name="From_Date")
    @Temporal(TemporalType.DATE)
    private Date fromDate;

    @Column(name="To_Date")
    @Temporal(TemporalType.DATE)
    private Date toDate;

    @Column(name="Purpose_Of_Travel")
    private String purposeOfTravel;

    @Column(name="Request_Status")
    private String requestStatus;

    @Column(name="Request_Approved_On")
    @Temporal(TemporalType.DATE)
    private Date requestApprovedOn;

    @Column(name="Priority")
    private String priority;

    @ManyToOne
    @JoinColumn(name="Location_Id",referencedColumnName="Id")
    private Location location;
}
