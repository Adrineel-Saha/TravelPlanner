package com.cognizant.employeetraveldesk.travelplanner.repositories;

import com.cognizant.employeetraveldesk.travelplanner.entities.TravelBudgetAllocation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface TravelBudgetAllocationRepository extends JpaRepository<TravelBudgetAllocation,Integer> {
    Optional<TravelBudgetAllocation> findByTravelRequestRequestId(int travelrequestId);
}
