package com.cognizant.employeetraveldesk.travelplanner.services;

import com.cognizant.employeetraveldesk.travelplanner.dtos.LocationDTO;

import java.util.List;

public interface LocationService {
    public List<LocationDTO> getAllLocations();
}
