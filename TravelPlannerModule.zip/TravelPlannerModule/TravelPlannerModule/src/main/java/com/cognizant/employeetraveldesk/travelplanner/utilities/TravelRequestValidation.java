package com.cognizant.employeetraveldesk.travelplanner.utilities;

import com.cognizant.employeetraveldesk.travelplanner.dtos.TravelRequestDTO;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Validation;
import jakarta.validation.Validator;

import java.util.Set;

public class TravelRequestValidation {
    public void validateTravelRequest(TravelRequestDTO travelRequestDTO) {
        Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
        Set<ConstraintViolation<TravelRequestDTO>> violations = validator.validate(travelRequestDTO);

        if (!violations.isEmpty()) {
            throw new ConstraintViolationException(violations);
        }
    }
}
