package com.cognizant.employeetraveldesk.travelplanner.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="Travel_Budget_Allocations")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TravelBudgetAllocation {
    @Id
    @Column(name="Id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name="Approved_Budget")
    private int approvedBudget;

    @Column(name="Approved_Mode_Of_Travel")
    private String approvedModeOfTravel;

    @Column(name="Approved_Hotel_Star_Rating")
    private String approvedHotelStarRating;

    @ManyToOne
    @JoinColumn(name="Travel_Request_Id",referencedColumnName="Request_Id")
    private TravelRequest travelRequest;

//    public void setApprovedBudget(Integer approvedBudget) {
//        if (approvedBudget != null) {
//            this.approvedBudget = approvedBudget;
//        }
//        else {
//            this.approvedBudget = 0;
//        }
//    }
}
