package com.cognizant.employeetraveldesk.travelplanner.services;

import com.cognizant.employeetraveldesk.travelplanner.dtos.TravelRequestDTO;
import com.cognizant.employeetraveldesk.travelplanner.utilities.TravelRequestValidation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TravelBudgetAllocationServiceImpl implements TravelBudgetAllocationService{
//    @Autowired
//    TravelBudgetAllocationRepository travelBudgetAllocationRepository;
    @Autowired
    EmployeeService employeeService;

    @Override
    public int calculateBudget(TravelRequestDTO travelRequestDTO) {
        TravelRequestValidation travelRequestValidation=new TravelRequestValidation();
        travelRequestValidation.validateTravelRequest(travelRequestDTO);

//        Optional<TravelBudgetAllocation> travelBudgetAllocationOptional=travelBudgetAllocationRepository.findByTravelRequestId(travelRequestDTO.getRequestId());
//        TravelBudgetAllocation travelBudgetAllocation=travelBudgetAllocationOptional.orElseThrow(()->new RuntimeException("Travel Budget Allocation not found with Travel Request Id: "+ travelRequestDTO.getRequestId());

        if(travelRequestDTO.getRequestStatus().equals("Approved")){
            int allowedDays = getAllowedDays(travelRequestDTO.getPriority());
            int actualDays = (int) ((travelRequestDTO.getToDate().getTime() - travelRequestDTO.getFromDate().getTime()) / (1000 * 60 * 60 * 24)) + 1;
            if (actualDays > allowedDays) {
                throw new IllegalArgumentException("Exceeded maximum allowed on-site days for " + travelRequestDTO.getPriority());
            }

            String grade = employeeService.getEmployeeGrade(travelRequestDTO.getRaisedByEmployeeId());
            int allowedBudget = calculateAllowedBudget(grade, actualDays);
            return allowedBudget;
        }
        else{
            throw new RuntimeException("Cannot calculate budget for non Approved Travel Requests");
        }

    }

    private int getAllowedDays(String priority) {
        switch (priority) {
            case "Priority 1":
                return 30;
            case "Priority 2":
                return 20;
            case "Priority 3":
                return 10;
            default:
                throw new IllegalArgumentException("Invalid priority: " + priority);
        }
    }

    private int calculateAllowedBudget(String grade, int days) {
        switch (grade) {
            case "Grade 1":
                return days * 10000;
            case "Grade 2":
                return days * 12500;
            case "Grade 3":
                return days * 15000;
            default:
                throw new IllegalArgumentException("Invalid employee grade: " + grade);
        }
    }
}
