package com.cognizant.employeetraveldesk.travelplanner.services;

import com.cognizant.employeetraveldesk.travelplanner.dtos.EmployeeDTO;
import com.cognizant.employeetraveldesk.travelplanner.entities.Employee;

import java.util.List;

public interface EmployeeService {
    public String getEmployeeGrade(int employeeId);
    public String getEmployeeRole(int employeeId);
    public String getEmployeeName(int employeeId);
    public List<Employee> listOfEmployees();
    public EmployeeDTO authenticateEmployee(String employeeName, String password);
}
