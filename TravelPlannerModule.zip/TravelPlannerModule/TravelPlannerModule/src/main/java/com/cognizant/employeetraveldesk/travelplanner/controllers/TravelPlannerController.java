package com.cognizant.employeetraveldesk.travelplanner.controllers;

import com.cognizant.employeetraveldesk.travelplanner.dtos.LocationDTO;
import com.cognizant.employeetraveldesk.travelplanner.dtos.TravelRequestDTO;
import com.cognizant.employeetraveldesk.travelplanner.dtos.TravelRequestDetailsDTO;
import com.cognizant.employeetraveldesk.travelplanner.dtos.UpdateTravelRequestDTO;
import com.cognizant.employeetraveldesk.travelplanner.services.LocationService;
import com.cognizant.employeetraveldesk.travelplanner.services.TravelBudgetAllocationService;
import com.cognizant.employeetraveldesk.travelplanner.services.TravelRequestService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("api/travelrequests")
@CrossOrigin(origins = "http://localhost:4200")
@Tag(name="TravelPlanner",description="TravelPlanner REST API")
public class TravelPlannerController {
    @Autowired
    LocationService locationService;
    @Autowired
    TravelRequestService travelRequestService;
    @Autowired
    TravelBudgetAllocationService travelBudgetAllocationService;

    @GetMapping("locations")
    @Operation(summary="Get all Locations",description="Retrieve a list of all locations")
    public ResponseEntity<List<LocationDTO>> getAllLocations(){
        log.info("Getting all Locations");

        List<LocationDTO> locationDTOList=locationService.getAllLocations();
        if(locationDTOList!=null && !locationDTOList.isEmpty()){
            return new ResponseEntity<>(locationDTOList, HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("new")
    @Operation(summary="Create a Travel_Request",description="Creates a new travel request")
    public ResponseEntity<Integer> addTravelRequest(@RequestBody TravelRequestDTO travelRequestDTO){
        log.info("Adding a new Travel Request: " + travelRequestDTO);

        TravelRequestDetailsDTO newTravelRequestDetailsDTO = travelRequestService.addTravelRequest(travelRequestDTO);
        if(newTravelRequestDetailsDTO !=null){
            return new ResponseEntity<>(newTravelRequestDetailsDTO.getRequestId(),HttpStatus.CREATED);
        }
        else{
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("{HRid}/pending")
    @Operation(summary="Get all pending Travel_Requests",description = "Getting newly created travel requests for approval")
    public ResponseEntity<List<TravelRequestDTO>> getAllPendingTravelRequests(@PathVariable("HRid") int HRid){
        log.info("Getting Pending Travel Requests with HRid: " + HRid);

        List<TravelRequestDTO> travelRequestDTOList=travelRequestService.getAllPendingTravelRequests(HRid);
        if(travelRequestDTOList!=null && !travelRequestDTOList.isEmpty()){
            return new ResponseEntity<>(travelRequestDTOList, HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("{trid}")
    @Operation(summary = "Get Approved Travel_Request",description = "Getting approved travel request by travel_request_id")
    public ResponseEntity<TravelRequestDetailsDTO> getApprovedTravelRequestDetails(@PathVariable("trid") int trid){
        log.info("Getting Approved Travel Request Details with trid: " + trid);

        TravelRequestDetailsDTO travelRequestDetailsDTO=travelRequestService.getApprovedTravelRequestDetails(trid);
        if(travelRequestDetailsDTO!=null){
            return new ResponseEntity<>(travelRequestDetailsDTO,HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("{trid}/update")
    @Operation(summary = "Approve or Reject Travel_Request",description = "Approving or rejecting a travel request by travel_request_id")
    public ResponseEntity<TravelRequestDetailsDTO> approveOrRejectTravelRequest(@PathVariable("trid") int trid,@RequestBody UpdateTravelRequestDTO updateTravelRequestDTO){
        log.info("Approving or rejecting a Travel Request: " + updateTravelRequestDTO + " with trid: " + trid);

        TravelRequestDetailsDTO travelRequestDetailsDTO=travelRequestService.approveOrRejectTravelRequest(trid,updateTravelRequestDTO);
//        log.info(String.valueOf(travelRequestDetailsDTO.getApprovedBudget()));

        if(travelRequestDetailsDTO!=null){
            return new ResponseEntity<>(travelRequestDetailsDTO,HttpStatus.ACCEPTED);
        }
        else{
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

//        log.info(String.valueOf(travelRequestDetailsDTO.getApprovedBudget()));
    }

    @PostMapping("calculateBudget")
    @Operation(summary="Calculate Budget",description="Calculating applicable Budget for travel")
    public ResponseEntity<Integer> calculateBudget(@RequestBody TravelRequestDTO travelRequestDTO){
        log.info("Calculating applicable Budget for travel");

        int budget=travelBudgetAllocationService.calculateBudget(travelRequestDTO);
        if(budget>0){
            return new ResponseEntity<>(budget,HttpStatus.CREATED);
        }
        else{
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }
}
