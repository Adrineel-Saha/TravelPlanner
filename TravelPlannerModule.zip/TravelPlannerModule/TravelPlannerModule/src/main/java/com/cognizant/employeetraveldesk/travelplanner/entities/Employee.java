package com.cognizant.employeetraveldesk.travelplanner.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Employees")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Employee {
    @Id
    @Column(name="Employee_Id")
    private int employeeId;

    @Column(name="Employee_Name")
    private String employeeName;

    @Column(name="Password")
    private String password;

    @Column(name="Role")
    private String role;

    @Column(name="Current_Grade")
    private String currentGrade;

    @Column(name="Is_Account_Locked")
    private boolean isAccountLocked;
}
