package com.cognizant.employeetraveldesk.travelplanner.dtos;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UpdateTravelRequestDTO {
    private int requestId;

    @NotNull
    @Pattern(regexp = "^(Approved|Rejected)$")
    private String requestStatus;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date requestApprovedOn;

//    private Integer approvedBudget=0;

    @Pattern(regexp = "^(Air|Train|Bus)$")
    private String approvedModeOfTravel;

    @Pattern(regexp = "^(3-Star|5-Star|7-Star)$")
    private String approvedHotelStarRating;
}
