package com.cognizant.employeetraveldesk.travelplanner.utilities;

import com.cognizant.employeetraveldesk.travelplanner.dtos.UpdateTravelRequestDTO;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Validation;
import jakarta.validation.Validator;

import java.util.Set;

public class UpdateTravelRequestValidation {
    public void validateUpdateTravelRequest(UpdateTravelRequestDTO updateTravelRequestDTO) {
        Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
        Set<ConstraintViolation<UpdateTravelRequestDTO>> violations = validator.validate(updateTravelRequestDTO);

        if (!violations.isEmpty()) {
            throw new ConstraintViolationException(violations);
        }
    }
}
